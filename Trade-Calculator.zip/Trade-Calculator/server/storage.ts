import { randomUUID } from "crypto";
import type { CalculationInput, TaxBreakdown, ParameterSettings } from "@shared/schema";
import { defaultParameters } from "@shared/schema";

// Stored calculation
export interface StoredCalculation {
  id: string;
  input: CalculationInput;
  ncmDescription: string;
  breakdown: TaxBreakdown;
  createdAt: string;
}

// Storage interface
export interface IStorage {
  // Calculations
  saveCalculation(
    input: CalculationInput,
    ncmDescription: string,
    breakdown: TaxBreakdown
  ): Promise<StoredCalculation>;
  getCalculation(id: string): Promise<StoredCalculation | undefined>;
  getRecentCalculations(limit?: number): Promise<StoredCalculation[]>;
  // Parameters
  getParameters(): Promise<ParameterSettings>;
  updateParameters(params: Partial<ParameterSettings>): Promise<ParameterSettings>;
}

export class MemStorage implements IStorage {
  private calculations: Map<string, StoredCalculation>;
  private parameters: ParameterSettings;

  constructor() {
    this.calculations = new Map();
    this.parameters = { ...defaultParameters };
  }

  async getParameters(): Promise<ParameterSettings> {
    return { ...this.parameters };
  }

  async updateParameters(params: Partial<ParameterSettings>): Promise<ParameterSettings> {
    this.parameters = {
      ...this.parameters,
      ...params,
      updatedAt: new Date().toISOString(),
    };
    return { ...this.parameters };
  }

  async saveCalculation(
    input: CalculationInput,
    ncmDescription: string,
    breakdown: TaxBreakdown
  ): Promise<StoredCalculation> {
    const id = randomUUID();
    const calculation: StoredCalculation = {
      id,
      input,
      ncmDescription,
      breakdown,
      createdAt: new Date().toISOString(),
    };
    this.calculations.set(id, calculation);
    return calculation;
  }

  async getCalculation(id: string): Promise<StoredCalculation | undefined> {
    return this.calculations.get(id);
  }

  async getRecentCalculations(limit: number = 10): Promise<StoredCalculation[]> {
    const all = Array.from(this.calculations.values());
    return all
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, limit);
  }
}

export const storage = new MemStorage();
