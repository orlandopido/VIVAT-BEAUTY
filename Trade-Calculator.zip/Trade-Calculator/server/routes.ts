import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupSession, registerAuthRoutes, isAuthenticated, isAdmin } from "./auth";
import {
  ncmCodes,
  originLocations,
  destinationLocations,
  brazilianStates,
  calculationInputSchema,
  parameterSettingsSchema,
  type TransportMode,
} from "@shared/schema";
import { calculateImportTaxes, searchNcmCodes, getNcmData } from "@shared/calculator";
import { db } from "./db";
import { users } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { sendResultEmail } from "./email";

async function ensureAdminExists() {
  try {
    const adminEmail = "opjunior@icloud.com";
    const [existingAdmin] = await db
      .select()
      .from(users)
      .where(eq(users.email, adminEmail))
      .limit(1);

    if (!existingAdmin) {
      const passwordHash = await bcrypt.hash("Admin@2025", 10);
      await db.insert(users).values({
        email: adminEmail,
        passwordHash,
        firstName: "ORLANDO",
        lastName: "JUNIOR",
        role: "admin",
      });
      console.log("Admin user created successfully");
    }
  } catch (error) {
    console.error("Error ensuring admin exists:", error);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  setupSession(app);
  registerAuthRoutes(app);
  
  await ensureAdminExists();
  // Search NCM codes
  app.get("/api/ncm", (req, res) => {
    const query = (req.query.q as string) || "";
    const results = searchNcmCodes(query);
    res.json(results);
  });

  // Get all NCM codes
  app.get("/api/ncm/all", (req, res) => {
    res.json(ncmCodes);
  });

  // Get NCM data with local tax rates (validates against SISCOMEX structure)
  app.get("/api/ncm/siscomex/:code", async (req, res) => {
    try {
      const code = req.params.code.replace(/\./g, '');
      const formattedCode = `${code.slice(0,4)}.${code.slice(4,6)}.${code.slice(6,8)}`;
      
      // Get local tax rates from our database
      const localNcm = ncmCodes.find(n => n.code === code);
      
      if (!localNcm) {
        return res.status(404).json({ 
          error: 'NCM not found in database',
          code: formattedCode,
          suggestion: 'Use GET /api/ncm/all to see available NCM codes'
        });
      }
      
      // Return local data with SISCOMEX-compatible format
      res.json({
        siscomex: {
          codigo: formattedCode,
          descricao: localNcm.description,
          dataInicio: "01/04/2022",
          ato: "Res Camex 272/2021",
          atualizacao: new Date().toLocaleDateString('pt-BR')
        },
        taxRates: {
          code: localNcm.code,
          description: localNcm.description,
          iiRate: localNcm.iiRate,
          ipiRate: localNcm.ipiRate,
          pisRate: localNcm.pisRate,
          cofinsRate: localNcm.cofinsRate
        },
        source: 'local_database'
      });
    } catch (error) {
      console.error('NCM lookup error:', error);
      res.status(500).json({ error: 'Failed to lookup NCM' });
    }
  });

  // Get origin locations filtered by transport mode
  app.get("/api/locations/origins", (req, res) => {
    const mode = req.query.mode as TransportMode | undefined;
    let locations = originLocations;
    
    if (mode === "air") {
      locations = originLocations.filter(l => l.type === "airport");
    } else if (mode === "maritime") {
      locations = originLocations.filter(l => l.type === "port");
    }
    
    // Group by country
    const grouped = locations.reduce((acc, loc) => {
      if (!acc[loc.country]) acc[loc.country] = [];
      acc[loc.country].push(loc);
      return acc;
    }, {} as Record<string, typeof locations>);
    
    res.json({ locations, grouped });
  });

  // Get destination locations filtered by transport mode
  app.get("/api/locations/destinations", (req, res) => {
    const mode = req.query.mode as TransportMode | undefined;
    let locations = destinationLocations;
    
    if (mode === "air") {
      locations = destinationLocations.filter(l => l.type === "airport");
    } else if (mode === "maritime") {
      locations = destinationLocations.filter(l => l.type === "port");
    }
    
    res.json({ locations });
  });

  // Get Brazilian states with ICMS rates
  app.get("/api/states", (req, res) => {
    res.json(brazilianStates);
  });

  // Fetch PTAX exchange rates from Banco Central do Brasil
  app.get("/api/ptax", async (req, res) => {
    try {
      const today = new Date();
      const formatDate = (d: Date) => {
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const dd = String(d.getDate()).padStart(2, '0');
        const yyyy = d.getFullYear();
        return `${mm}-${dd}-${yyyy}`;
      };
      
      // Try today, if no data try previous days (weekends/holidays)
      let usdRate = null;
      let eurRate = null;
      
      for (let i = 0; i < 5; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(checkDate.getDate() - i);
        const dateStr = formatDate(checkDate);
        
        // Fetch USD rate
        if (!usdRate) {
          const usdUrl = `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoDolarDia(dataCotacao=@dataCotacao)?@dataCotacao='${dateStr}'&$format=json`;
          const usdResponse = await fetch(usdUrl);
          const usdData = await usdResponse.json();
          if (usdData.value && usdData.value.length > 0) {
            usdRate = usdData.value[usdData.value.length - 1].cotacaoVenda;
          }
        }
        
        // Fetch EUR rate
        if (!eurRate) {
          const eurUrl = `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoMoedaDia(moeda=@moeda,dataCotacao=@dataCotacao)?@moeda='EUR'&@dataCotacao='${dateStr}'&$format=json`;
          const eurResponse = await fetch(eurUrl);
          const eurData = await eurResponse.json();
          if (eurData.value && eurData.value.length > 0) {
            eurRate = eurData.value[eurData.value.length - 1].cotacaoVenda;
          }
        }
        
        if (usdRate && eurRate) break;
      }
      
      if (!usdRate || !eurRate) {
        return res.status(404).json({ error: "Cotação não disponível" });
      }
      
      res.json({
        usd: usdRate,
        eur: eurRate,
        date: new Date().toISOString(),
      });
    } catch (error) {
      console.error("Error fetching PTAX:", error);
      res.status(500).json({ error: "Erro ao buscar cotação PTAX" });
    }
  });

  // Get system parameters (admin only)
  app.get("/api/parameters", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const params = await storage.getParameters();
      res.json(params);
    } catch (error) {
      console.error("Error getting parameters:", error);
      res.status(500).json({ error: "Erro ao buscar parâmetros" });
    }
  });

  // Update system parameters (admin only)
  app.put("/api/parameters", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const parseResult = parameterSettingsSchema.partial().safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Dados inválidos", 
          details: parseResult.error.issues 
        });
      }
      
      const updated = await storage.updateParameters(parseResult.data);
      res.json(updated);
    } catch (error) {
      console.error("Error updating parameters:", error);
      res.status(500).json({ error: "Erro ao atualizar parâmetros" });
    }
  });

  // Calculate import taxes (uses admin parameters)
  app.post("/api/calculate", async (req, res) => {
    try {
      const parseResult = calculationInputSchema.safeParse(req.body);
      
      if (!parseResult.success) {
        return res.status(400).json({ 
          error: "Dados inválidos", 
          details: parseResult.error.issues 
        });
      }
      
      const input = parseResult.data;
      const ncmData = getNcmData(input.ncmCode);
      
      if (!ncmData) {
        return res.status(400).json({ 
          error: "Código NCM não encontrado" 
        });
      }
      
      // Fetch admin parameters for calculation
      const params = await storage.getParameters();
      
      // Calculate using parameters
      const breakdown = calculateImportTaxes(input, params);
      
      // Save calculation
      const saved = await storage.saveCalculation(
        input,
        ncmData.description,
        breakdown
      );
      
      res.json({
        id: saved.id,
        input,
        ncmDescription: ncmData.description,
        breakdown,
        createdAt: saved.createdAt,
      });
    } catch (error) {
      console.error("Calculation error:", error);
      res.status(500).json({ 
        error: "Erro ao calcular impostos" 
      });
    }
  });

  // Get calculation by ID
  app.get("/api/calculations/:id", async (req, res) => {
    const calculation = await storage.getCalculation(req.params.id);
    
    if (!calculation) {
      return res.status(404).json({ error: "Cálculo não encontrado" });
    }
    
    res.json(calculation);
  });

  // Get recent calculations
  app.get("/api/calculations", async (req, res) => {
    const limit = parseInt(req.query.limit as string) || 10;
    const calculations = await storage.getRecentCalculations(limit);
    res.json(calculations);
  });

  // Compare air vs maritime
  app.post("/api/compare", async (req, res) => {
    try {
      const baseInput = req.body;
      
      // Validate base input (without transport mode requirement)
      const { transportMode, originId, destinationId, ...rest } = baseInput;
      
      // Find matching origin/destination for each mode
      const originCountry = originLocations.find(l => l.id === originId)?.country;
      const destState = destinationLocations.find(l => l.id === destinationId)?.state;
      
      const airOrigin = originLocations.find(l => l.type === "airport" && l.country === originCountry);
      const maritimeOrigin = originLocations.find(l => l.type === "port" && l.country === originCountry);
      const airDest = destinationLocations.find(l => l.type === "airport" && l.state === destState);
      const maritimeDest = destinationLocations.find(l => l.type === "port" && l.state === destState);
      
      if (!airOrigin || !maritimeOrigin || !airDest || !maritimeDest) {
        return res.status(400).json({ 
          error: "Não foi possível encontrar rotas equivalentes para comparação" 
        });
      }
      
      const airInput = {
        ...rest,
        transportMode: "air" as const,
        originId: airOrigin.id,
        destinationId: airDest.id,
      };
      
      const maritimeInput = {
        ...rest,
        transportMode: "maritime" as const,
        originId: maritimeOrigin.id,
        destinationId: maritimeDest.id,
      };
      
      const airParseResult = calculationInputSchema.safeParse(airInput);
      const maritimeParseResult = calculationInputSchema.safeParse(maritimeInput);
      
      if (!airParseResult.success || !maritimeParseResult.success) {
        return res.status(400).json({ error: "Dados inválidos para comparação" });
      }
      
      // Fetch parameters for calculations
      const params = await storage.getParameters();
      
      const airBreakdown = calculateImportTaxes(airParseResult.data, params);
      const maritimeBreakdown = calculateImportTaxes(maritimeParseResult.data, params);
      
      res.json({
        air: {
          input: airParseResult.data,
          breakdown: airBreakdown,
        },
        maritime: {
          input: maritimeParseResult.data,
          breakdown: maritimeBreakdown,
        },
        difference: maritimeBreakdown.totalLandedCost - airBreakdown.totalLandedCost,
        cheaperMode: airBreakdown.totalLandedCost < maritimeBreakdown.totalLandedCost ? "air" : "maritime",
      });
    } catch (error) {
      console.error("Comparison error:", error);
      res.status(500).json({ error: "Erro ao comparar modalidades" });
    }
  });

  // Send result by email (requires authenticated user) - Resend integration
  app.post("/api/send-result-email", isAuthenticated, async (req, res) => {
    try {
      const { result, userEmail, userName } = req.body;
      
      if (!result || !userEmail) {
        return res.status(400).json({ error: "Dados incompletos" });
      }
      
      const emailResult = await sendResultEmail(userEmail, userName || "Cliente", result);
      
      if (emailResult.success) {
        res.json({ 
          success: true, 
          message: `Resultado enviado para ${userEmail}`,
          messageId: emailResult.messageId
        });
      } else {
        res.status(500).json({ 
          error: emailResult.error || "Erro ao enviar email" 
        });
      }
    } catch (error: any) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: error.message || "Erro ao enviar email" });
    }
  });

  return httpServer;
}
