import { Resend } from 'resend';
import type { TaxBreakdown, CalculationInput } from '@shared/schema';

function getResendClient() {
  const apiKey = process.env.RESEND_API_KEY;
  const fromEmail = process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev';
  
  if (!apiKey) {
    throw new Error('RESEND_API_KEY not configured');
  }
  
  return {
    client: new Resend(apiKey),
    fromEmail
  };
}

function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL'
  }).format(value);
}

function formatPercentage(value: number): string {
  return `${value.toFixed(2)}%`;
}

export async function sendResultEmail(
  toEmail: string,
  userName: string,
  result: { input: CalculationInput; breakdown: TaxBreakdown }
): Promise<{ success: boolean; messageId?: string; error?: string }> {
  try {
    const { client, fromEmail } = await getResendClient();
    const { input, breakdown } = result;

    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; background-color: #f5f5f5;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f5f5f5; padding: 20px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
          
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%); padding: 32px; text-align: center;">
              <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600;">Calc.Autos</h1>
              <p style="margin: 8px 0 0; color: #94a3b8; font-size: 14px;">Calculadora de Importacao de Veiculos</p>
            </td>
          </tr>

          <!-- Greeting -->
          <tr>
            <td style="padding: 32px 32px 16px;">
              <p style="margin: 0; color: #374151; font-size: 16px;">Ola <strong>${userName}</strong>,</p>
              <p style="margin: 12px 0 0; color: #6b7280; font-size: 14px;">Segue o resultado do seu calculo de importacao:</p>
            </td>
          </tr>

          <!-- Vehicle Info -->
          <tr>
            <td style="padding: 0 32px 24px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border-radius: 8px; overflow: hidden;">
                <tr>
                  <td style="padding: 16px; border-bottom: 1px solid #e2e8f0;">
                    <p style="margin: 0; color: #64748b; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px;">Veiculo</p>
                    <p style="margin: 4px 0 0; color: #0f172a; font-size: 18px; font-weight: 600;">${input.productName}</p>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">NCM</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px; font-weight: 500;">${input.ncmCode}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-top: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">Valor FOB</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px; font-weight: 500;">USD ${input.fobValueUsd.toLocaleString('en-US', { minimumFractionDigits: 2 })}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-top: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">Transporte</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px; font-weight: 500;">${input.transportMode === 'air' ? 'Aereo' : 'Maritimo'} (${input.originId} → ${input.destinationId})</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- CIF Section -->
          <tr>
            <td style="padding: 0 32px 24px;">
              <p style="margin: 0 0 12px; color: #64748b; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">Composicao CIF</p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border-radius: 8px;">
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">FOB (BRL)</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.fobBrl)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">Frete Internacional</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.freightBrl)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">Seguro</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.insuranceBrl)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; background-color: #e0f2fe;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #0369a1; font-size: 14px; font-weight: 600;">CIF Total</td>
                        <td style="text-align: right; color: #0369a1; font-size: 14px; font-weight: 600;">${formatCurrency(breakdown.cifBrl)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Taxes Section -->
          <tr>
            <td style="padding: 0 32px 24px;">
              <p style="margin: 0 0 12px; color: #64748b; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">Impostos</p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8fafc; border-radius: 8px;">
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">II (${formatPercentage(breakdown.iiRate)})</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.iiValue)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">IPI (${formatPercentage(breakdown.ipiRate)})</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.ipiValue)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">PIS (${formatPercentage(breakdown.pisRate)})</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.pisValue)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">COFINS (${formatPercentage(breakdown.cofinsRate)})</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.cofinsValue)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">ICMS (${formatPercentage(breakdown.icmsRate)})</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.icmsValue)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; border-bottom: 1px solid #e2e8f0;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #64748b; font-size: 13px;">Taxa Siscomex</td>
                        <td style="text-align: right; color: #0f172a; font-size: 13px;">${formatCurrency(breakdown.siscomexFee)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
                <tr>
                  <td style="padding: 12px 16px; background-color: #fef3c7;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #92400e; font-size: 14px; font-weight: 600;">Total Impostos</td>
                        <td style="text-align: right; color: #92400e; font-size: 14px; font-weight: 600;">${formatCurrency(breakdown.totalTaxes)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Operational Costs -->
          <tr>
            <td style="padding: 0 32px 24px;">
              <p style="margin: 0 0 12px; color: #64748b; font-size: 11px; text-transform: uppercase; letter-spacing: 0.5px; font-weight: 600;">Despesas Operacionais</p>
              <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f0fdf4; border-radius: 8px;">
                <tr>
                  <td style="padding: 12px 16px;">
                    <table width="100%" cellpadding="0" cellspacing="0">
                      <tr>
                        <td style="color: #166534; font-size: 14px; font-weight: 600;">Total Despesas</td>
                        <td style="text-align: right; color: #166534; font-size: 14px; font-weight: 600;">${formatCurrency(breakdown.totalOperational)}</td>
                      </tr>
                    </table>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Total -->
          <tr>
            <td style="padding: 0 32px 32px;">
              <table width="100%" cellpadding="0" cellspacing="0" style="background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%); border-radius: 12px;">
                <tr>
                  <td style="padding: 24px; text-align: center;">
                    <p style="margin: 0; color: #94a3b8; font-size: 12px; text-transform: uppercase; letter-spacing: 1px;">Custo Total Nacionalizado</p>
                    <p style="margin: 8px 0; color: #ffffff; font-size: 36px; font-weight: 700;">${formatCurrency(breakdown.totalLandedCost)}</p>
                    <p style="margin: 0; color: #64748b; font-size: 12px;">CIF + Impostos + Despesas</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 32px; background-color: #f8fafc; border-top: 1px solid #e2e8f0;">
              <p style="margin: 0; color: #64748b; font-size: 12px; text-align: center;">Este e um calculo estimativo. Consulte um despachante aduaneiro para valores exatos.</p>
              <p style="margin: 12px 0 0; color: #94a3b8; font-size: 11px; text-align: center;">Calc.Autos - Importacao de Veiculos de Luxo</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;

    const replyTo = process.env.RESEND_REPLY_TO || undefined;
    
    const response = await client.emails.send({
      from: fromEmail,
      to: toEmail,
      replyTo: replyTo,
      subject: `Resultado da Importação: ${input.productName}`,
      html: htmlContent,
    });

    if (response.error) {
      console.error('Resend error:', response.error);
      return { success: false, error: response.error.message };
    }

    return { success: true, messageId: response.data?.id };
  } catch (error: any) {
    console.error('Error sending email:', error);
    return { success: false, error: error.message || 'Erro ao enviar email' };
  }
}
