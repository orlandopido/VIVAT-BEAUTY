import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Save, Loader2, RefreshCw } from "lucide-react";
import type { ParameterSettings } from "@shared/schema";

function formatBrazilianNumber(value: number, decimals: number = 2): string {
  return value.toLocaleString('pt-BR', { minimumFractionDigits: decimals, maximumFractionDigits: decimals });
}

function parseBrazilianNumber(value: string): number {
  const cleaned = value.replace(/\./g, '').replace(',', '.');
  return parseFloat(cleaned);
}

function validateBrazilianNumber(v: string): boolean {
  const num = parseBrazilianNumber(v);
  return !isNaN(num) && num >= 0;
}

function validateBrazilianNumberPositive(v: string): boolean {
  const num = parseBrazilianNumber(v);
  return !isNaN(num) && num > 0;
}

function validateBrazilianPercent(v: string): boolean {
  const num = parseBrazilianNumber(v);
  return !isNaN(num) && num >= 0 && num <= 100;
}

const parameterFormSchema = z.object({
  exchangeRateUsd: z.string().refine(validateBrazilianNumberPositive, "Taxa USD inválida"),
  exchangeRateEur: z.string().refine(validateBrazilianNumberPositive, "Taxa EUR inválida"),
  maritimeFreightUsd: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  maritimeFreightBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  insurancePercent: z.string().refine(validateBrazilianPercent, "Percentual inválido"),
  afrmmPercent: z.string().refine(validateBrazilianPercent, "Percentual inválido"),
  customsClearanceBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  maritimeAgencyBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  roadTransportBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  thcBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  customsBrokerPercent: z.string().refine(validateBrazilianPercent, "Percentual inválido"),
  sdaBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
  denatranBrl: z.string().refine(validateBrazilianNumber, "Valor inválido"),
});

type ParameterFormData = z.infer<typeof parameterFormSchema>;

export function ParameterSettingsPanel() {
  const { toast } = useToast();

  const { data: parameters, isLoading } = useQuery<ParameterSettings>({
    queryKey: ["/api/parameters"],
  });

  const form = useForm<ParameterFormData>({
    resolver: zodResolver(parameterFormSchema),
    defaultValues: {
      exchangeRateUsd: "",
      exchangeRateEur: "",
      maritimeFreightUsd: "2.500,00",
      maritimeFreightBrl: "15.000,00",
      insurancePercent: "0,50",
      afrmmPercent: "8,00",
      customsClearanceBrl: "2.500,00",
      maritimeAgencyBrl: "1.500,00",
      roadTransportBrl: "3.500,00",
      thcBrl: "941,00",
      customsBrokerPercent: "2,50",
      sdaBrl: "2.162,00",
      denatranBrl: "4.000,00",
    },
    values: parameters ? {
      exchangeRateUsd: formatBrazilianNumber(parameters.exchangeRateUsd),
      exchangeRateEur: formatBrazilianNumber(parameters.exchangeRateEur),
      maritimeFreightUsd: formatBrazilianNumber(parameters.maritimeFreightUsd),
      maritimeFreightBrl: formatBrazilianNumber(parameters.maritimeFreightBrl),
      insurancePercent: formatBrazilianNumber(parameters.insurancePercent ?? 0.5),
      afrmmPercent: formatBrazilianNumber(parameters.afrmmPercent),
      customsClearanceBrl: formatBrazilianNumber(parameters.customsClearanceBrl),
      maritimeAgencyBrl: formatBrazilianNumber(parameters.maritimeAgencyBrl),
      roadTransportBrl: formatBrazilianNumber(parameters.roadTransportBrl),
      thcBrl: formatBrazilianNumber(parameters.thcBrl),
      customsBrokerPercent: formatBrazilianNumber(parameters.customsBrokerPercent),
      sdaBrl: formatBrazilianNumber(parameters.sdaBrl),
      denatranBrl: formatBrazilianNumber(parameters.denatranBrl),
    } : undefined,
  });

  const updateMutation = useMutation({
    mutationFn: async (data: Partial<ParameterSettings>) => {
      const response = await apiRequest("PUT", "/api/parameters", data);
      return await response.json() as ParameterSettings;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/parameters"] });
      toast({
        title: "Parâmetros salvos",
        description: "Os parâmetros foram atualizados com sucesso.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao salvar",
        description: error.message || "Não foi possível salvar os parâmetros.",
        variant: "destructive",
      });
    },
  });

  const ptaxFetchedRef = useRef(false);

  const fetchPtaxMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/ptax");
      if (!response.ok) throw new Error("Erro ao buscar cotação");
      return await response.json() as { usd: number; eur: number; date: string };
    },
    onSuccess: (data) => {
      form.setValue("exchangeRateUsd", formatBrazilianNumber(data.usd, 4));
      form.setValue("exchangeRateEur", formatBrazilianNumber(data.eur, 4));
      queryClient.invalidateQueries({ queryKey: ["/api/parameters"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao buscar cotação",
        description: error.message || "Não foi possível buscar a cotação PTAX.",
        variant: "destructive",
      });
    },
  });

  // Auto-fetch PTAX rates when component mounts
  useEffect(() => {
    if (!ptaxFetchedRef.current && !isLoading) {
      ptaxFetchedRef.current = true;
      fetchPtaxMutation.mutate();
    }
  }, [isLoading]);

  const onSubmit = (data: ParameterFormData) => {
    const params: Partial<ParameterSettings> = {
      exchangeRateUsd: parseBrazilianNumber(data.exchangeRateUsd),
      exchangeRateEur: parseBrazilianNumber(data.exchangeRateEur),
      maritimeFreightUsd: parseBrazilianNumber(data.maritimeFreightUsd),
      maritimeFreightBrl: parseBrazilianNumber(data.maritimeFreightBrl),
      insurancePercent: parseBrazilianNumber(data.insurancePercent),
      afrmmPercent: parseBrazilianNumber(data.afrmmPercent),
      customsClearanceBrl: parseBrazilianNumber(data.customsClearanceBrl),
      maritimeAgencyBrl: parseBrazilianNumber(data.maritimeAgencyBrl),
      roadTransportBrl: parseBrazilianNumber(data.roadTransportBrl),
      thcBrl: parseBrazilianNumber(data.thcBrl),
      customsBrokerPercent: parseBrazilianNumber(data.customsBrokerPercent),
      sdaBrl: parseBrazilianNumber(data.sdaBrl),
      denatranBrl: parseBrazilianNumber(data.denatranBrl),
    };
    updateMutation.mutate(params);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-2">
        <div className="flex items-center justify-between gap-2">
          <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Cotações de Câmbio (PTAX)</h4>
          {fetchPtaxMutation.isPending && (
            <div className="flex items-center gap-2 text-muted-foreground text-sm">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Buscando...</span>
            </div>
          )}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="exchangeRateUsd"
            render={({ field }) => (
              <FormItem>
                <FormLabel>US$ 1,00 = R$</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-exchange-rate-usd"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="exchangeRateEur"
            render={({ field }) => (
              <FormItem>
                <FormLabel>EUR 1,00 = R$</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-exchange-rate-eur"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="maritimeFreightUsd"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Frete Marítimo (US$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-freight-usd"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="maritimeFreightBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Frete Marítimo (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-freight-brl"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="insurancePercent"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Seguro (%)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,50"
                    data-testid="input-param-insurance-percent"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="afrmmPercent"
            render={({ field }) => (
              <FormItem>
                <FormLabel>AFRMM - Marinha Mercante (%)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-afrmm"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="customsBrokerPercent"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Despachante Aduaneiro (%)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-broker"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customsClearanceBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Desembaraço Aduaneiro (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-customs"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="maritimeAgencyBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Agência Marítima (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-agency"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="roadTransportBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Transporte Rodoviário (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-transport"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="thcBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>THC / Capatazias (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-thc"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="sdaBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>S.D.A. - Sindicato (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-sda"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField
            control={form.control}
            name="denatranBrl"
            render={({ field }) => (
              <FormItem>
                <FormLabel>DENATRAN (R$)</FormLabel>
                <FormControl>
                  <Input
                    {...field}
                    type="text"
                    placeholder="0,00"
                    data-testid="input-param-denatran"
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button
            type="submit"
            className="flex-1 gap-2"
            disabled={updateMutation.isPending}
            data-testid="button-save-params"
          >
            {updateMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <Save className="h-4 w-4" />
            )}
            Salvar Parâmetros
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={() => form.reset()}
            className="gap-2"
            data-testid="button-reset-params"
          >
            <RefreshCw className="h-4 w-4" />
            Restaurar
          </Button>
        </div>

        {parameters?.updatedAt && (
          <p className="text-xs text-muted-foreground text-center pt-2">
            Última atualização: {new Date(parameters.updatedAt).toLocaleString("pt-BR")}
          </p>
        )}
      </form>
    </Form>
  );
}
