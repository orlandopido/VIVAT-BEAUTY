import { useState, useMemo, useCallback, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest } from "@/lib/queryClient";
import { Plane, Ship, Calculator, MapPin, Car, DollarSign, Scale, ArrowRight, TrendingUp, FileText, RotateCcw, ChevronDown, Loader2, AlertCircle, Settings, LogIn, LogOut, User, UserPlus, Eye, EyeOff, Mail } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { ParameterSettingsPanel } from "@/components/parameter-settings";
import {
  ncmCodes,
  originLocations,
  destinationLocations,
  vehicleBrands,
  vehicleModels,
  getVehicleModelsByBrand,
  getFuelTypeLabel,
  type NcmCode,
  type Location,
  type TransportMode,
  type TaxBreakdown,
  type CalculationInput,
  type VehicleBrand,
  type VehicleModel,
  type ParameterSettings,
} from "@shared/schema";
import { formatCurrency, formatCurrencyValue, formatPercentage } from "@shared/calculator";

const formSchema = z.object({
  brandId: z.string().min(1, "Selecione a marca do veículo"),
  modelId: z.string().min(1, "Selecione o modelo do veículo"),
  ncmCode: z.string().min(8, "Código NCM inválido"),
  fobCurrency: z.enum(["USD", "EUR"]),
  fobValue: z.string().refine(v => !isNaN(parseFloat(v)) && parseFloat(v) > 0, "Valor FOB inválido"),
  weightKg: z.string().refine(v => !isNaN(parseFloat(v)) && parseFloat(v) > 0, "Peso inválido"),
  transportMode: z.enum(["air", "maritime"]),
  originId: z.string().min(1, "Local de embarque é obrigatório"),
  destinationId: z.string().min(1, "Local de descarga é obrigatório"),
  exchangeRate: z.string().refine(v => !isNaN(parseFloat(v)) && parseFloat(v) > 0, "Taxa de câmbio inválida"),
});

type FormData = z.infer<typeof formSchema>;

interface CalculationResponse {
  id: string;
  input: CalculationInput;
  ncmDescription: string;
  breakdown: TaxBreakdown;
  createdAt: string;
}

interface ComparisonResponse {
  air: { input: CalculationInput; breakdown: TaxBreakdown };
  maritime: { input: CalculationInput; breakdown: TaxBreakdown };
  difference: number;
  cheaperMode: "air" | "maritime";
}

function TaxResultCard({ breakdown, transportMode, isLoading, onEmail, userEmail, isSendingEmail }: { 
  breakdown: TaxBreakdown | null; 
  transportMode: TransportMode; 
  isLoading?: boolean;
  onEmail?: () => void;
  userEmail?: string;
  isSendingEmail?: boolean;
}) {
  if (isLoading) {
    return (
      <Card className="border-card-border">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-48" />
          <Skeleton className="h-4 w-32 mt-2" />
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-3">
            <Skeleton className="h-4 w-40" />
            <div className="grid grid-cols-2 gap-3">
              {[1, 2, 3, 4].map(i => (
                <Skeleton key={i} className="h-12 w-full" />
              ))}
            </div>
          </div>
          <div className="space-y-3">
            <Skeleton className="h-4 w-32" />
            <Skeleton className="h-48 w-full" />
          </div>
          <Skeleton className="h-24 w-full" />
        </CardContent>
      </Card>
    );
  }

  if (!breakdown) return null;

  const taxes = [
    { name: "II (Imposto de Importação)", rate: breakdown.iiRate, value: breakdown.iiValue },
    { name: "IPI (Produtos Industrializados)", rate: breakdown.ipiRate, value: breakdown.ipiValue },
    { name: "PIS-Importação", rate: breakdown.pisRate, value: breakdown.pisValue },
    { name: "COFINS-Importação", rate: breakdown.cofinsRate, value: breakdown.cofinsValue },
    { name: "Taxa Siscomex", rate: null, value: breakdown.siscomexFee },
    { name: "ICMS", rate: breakdown.icmsRate, value: breakdown.icmsValue },
  ];

  const taxPercentage = (breakdown.totalTaxes / breakdown.cifBrl) * 100;

  // Build operational expenses list (only show non-zero values)
  const opExp = breakdown.operationalExpenses;
  const operationalItems = [
    { name: "AFRMM (Marinha Mercante)", value: opExp.afrmm },
    { name: "Capatazias / THC", value: opExp.thc },
    { name: "Armazenagem Zona Primária", value: opExp.primaryStorage },
    { name: "Remoção Zona Secundária", value: opExp.removalFee },
    { name: "Armazenagem Zona Secundária", value: opExp.secondaryStorage },
    { name: "Despachante Aduaneiro", value: opExp.customsBroker },
    { name: "S.D.A. (Sindicato Despachantes)", value: opExp.customsBrokerUnion },
    { name: "Agente de Carga", value: opExp.cargoAgent },
    { name: "Transporte Rodoviário", value: opExp.domesticTransport },
    { name: "Licença de Importação", value: opExp.importLicense },
    { name: "GRU/CAT", value: opExp.gruCat },
    { name: "DENATRAN", value: opExp.denatran },
  ].filter(item => item.value > 0);

  return (
    <Card className="border-card-border">
      <CardHeader className="pb-4">
        <div className="flex items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2 text-xl font-semibold">
            <TrendingUp className="h-5 w-5 text-primary" />
            Resultado
          </CardTitle>
          {userEmail && (
            <Button 
              variant="outline" 
              size="sm"
              className="gap-2" 
              onClick={onEmail}
              disabled={isSendingEmail}
              data-testid="button-email-result"
            >
              {isSendingEmail ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Mail className="h-4 w-4" />
              )}
              Enviar Email
            </Button>
          )}
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground" data-testid="text-transport-mode">
          {transportMode === "air" ? (
            <><Plane className="h-4 w-4" /> Transporte Aéreo</>
          ) : (
            <><Ship className="h-4 w-4" /> Transporte Marítimo</>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Cost Components */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Composição do Custo</h4>
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
              <span className="text-muted-foreground">FOB (BRL)</span>
              <span className="font-semibold tabular-nums" data-testid="text-fob-brl">{formatCurrency(breakdown.fobBrl)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
              <span className="text-muted-foreground">Frete</span>
              <span className="font-semibold tabular-nums" data-testid="text-freight">{formatCurrency(breakdown.freightBrl)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-muted/50 rounded-md">
              <span className="text-muted-foreground">Seguro</span>
              <span className="font-semibold tabular-nums" data-testid="text-insurance">{formatCurrency(breakdown.insuranceBrl)}</span>
            </div>
            <div className="flex justify-between items-center p-3 bg-primary/10 rounded-md border border-primary/20">
              <span className="font-medium">CIF Total</span>
              <span className="font-bold tabular-nums text-primary" data-testid="text-cif">{formatCurrency(breakdown.cifBrl)}</span>
            </div>
          </div>
        </div>

        {/* Tax Breakdown Table */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Impostos e Taxas</h4>
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm" data-testid="table-tax-breakdown">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-medium">Impostos</th>
                  <th className="text-right p-3 font-medium">Alíquota %</th>
                  <th className="text-right p-3 font-medium">Valor R$</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {taxes.map((tax, index) => (
                  <tr key={tax.name} className={index % 2 === 0 ? "bg-background" : "bg-muted/30"} data-testid={`row-tax-${index}`}>
                    <td className="p-3 text-muted-foreground">{tax.name}</td>
                    <td className="p-3 text-right tabular-nums">
                      {tax.rate !== null ? tax.rate.toFixed(2).replace('.', ',') : "-"}
                    </td>
                    <td className="p-3 text-right font-medium tabular-nums">{formatCurrencyValue(tax.value)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-primary/10">
                <tr>
                  <td className="p-3 font-semibold">Total de Impostos</td>
                  <td className="p-3 text-right text-muted-foreground tabular-nums" data-testid="text-tax-percentage">
                    {taxPercentage.toFixed(2).replace('.', ',')}
                  </td>
                  <td className="p-3 text-right font-bold tabular-nums text-primary" data-testid="text-total-taxes">
                    {formatCurrencyValue(breakdown.totalTaxes)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Operational Expenses Table */}
        <div className="space-y-3">
          <h4 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">Despesas Portuárias e Aduaneiras</h4>
          <div className="border rounded-md overflow-hidden">
            <table className="w-full text-sm" data-testid="table-operational-expenses">
              <thead className="bg-muted/50">
                <tr>
                  <th className="text-left p-3 font-medium">Despesa</th>
                  <th className="text-right p-3 font-medium">Valor R$</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {operationalItems.map((item, index) => (
                  <tr key={item.name} className={index % 2 === 0 ? "bg-background" : "bg-muted/30"} data-testid={`row-operational-${index}`}>
                    <td className="p-3 text-muted-foreground">{item.name}</td>
                    <td className="p-3 text-right font-medium tabular-nums">{formatCurrencyValue(item.value)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-amber-500/10 dark:bg-amber-500/20">
                <tr>
                  <td className="p-3 font-semibold">Total Despesas Operacionais</td>
                  <td className="p-3 text-right font-bold tabular-nums text-amber-600 dark:text-amber-400" data-testid="text-total-operational">
                    {formatCurrencyValue(breakdown.totalOperational)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        {/* Tax Burden Visualization */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Carga Tributária sobre CIF</span>
            <span className="font-semibold">{formatPercentage(taxPercentage)}</span>
          </div>
          <div className="h-3 bg-muted rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-primary to-primary/70 rounded-full transition-all duration-500"
              style={{ width: `${Math.min(taxPercentage, 100)}%` }}
              data-testid="progress-tax-burden"
            />
          </div>
        </div>

      </CardContent>
    </Card>
  );
}

function ComparisonCard({ comparison, isLoading }: { comparison: ComparisonResponse | null; isLoading?: boolean }) {
  if (isLoading) {
    return (
      <Card className="border-card-border mt-6">
        <CardHeader className="pb-4">
          <Skeleton className="h-6 w-64" />
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <Skeleton className="h-28" />
            <Skeleton className="h-28" />
          </div>
          <Skeleton className="h-12 mt-4" />
        </CardContent>
      </Card>
    );
  }

  if (!comparison) return null;

  const { air, maritime, difference, cheaperMode } = comparison;

  return (
    <Card className="border-card-border mt-6" data-testid="card-comparison">
      <CardHeader className="pb-4">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <ArrowRight className="h-5 w-5 text-primary" />
          Comparação Aéreo vs Marítimo
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg border-2 transition-all ${
            cheaperMode === "air" 
              ? "border-green-500/50 bg-green-50 dark:bg-green-950/30" 
              : "border-border bg-muted/30"
          }`} data-testid="card-comparison-air">
            <div className="flex items-center gap-2 mb-2">
              <Plane className="h-5 w-5 text-blue-500" />
              <span className="font-medium">Aéreo</span>
              {cheaperMode === "air" && (
                <span className="ml-auto text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">
                  Mais Barato
                </span>
              )}
            </div>
            <p className="text-2xl font-bold tabular-nums" data-testid="text-air-cost">
              {formatCurrency(air.breakdown.totalLandedCost)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Frete: {formatCurrency(air.breakdown.freightBrl)} | Desp: {formatCurrency(air.breakdown.totalOperational)}
            </p>
          </div>
          <div className={`p-4 rounded-lg border-2 transition-all ${
            cheaperMode === "maritime" 
              ? "border-green-500/50 bg-green-50 dark:bg-green-950/30" 
              : "border-border bg-muted/30"
          }`} data-testid="card-comparison-maritime">
            <div className="flex items-center gap-2 mb-2">
              <Ship className="h-5 w-5 text-cyan-500" />
              <span className="font-medium">Marítimo</span>
              {cheaperMode === "maritime" && (
                <span className="ml-auto text-xs bg-green-500 text-white px-2 py-0.5 rounded-full">
                  Mais Barato
                </span>
              )}
            </div>
            <p className="text-2xl font-bold tabular-nums" data-testid="text-maritime-cost">
              {formatCurrency(maritime.breakdown.totalLandedCost)}
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Frete: {formatCurrency(maritime.breakdown.freightBrl)} | Desp: {formatCurrency(maritime.breakdown.totalOperational)}
            </p>
          </div>
        </div>
        <div className="mt-4 p-3 bg-muted/50 rounded-md text-center text-sm" data-testid="text-comparison-difference">
          Diferença: <span className="font-semibold">{formatCurrency(Math.abs(difference))}</span>
          <span className="text-muted-foreground"> ({formatPercentage(Math.abs(difference / air.breakdown.totalLandedCost) * 100)})</span>
        </div>
      </CardContent>
    </Card>
  );
}

function ErrorMessage({ message }: { message: string }) {
  return (
    <div className="flex items-center gap-2 p-4 bg-destructive/10 border border-destructive/20 rounded-lg text-destructive" data-testid="alert-error">
      <AlertCircle className="h-5 w-5 flex-shrink-0" />
      <p className="text-sm">{message}</p>
    </div>
  );
}

export default function Home() {
  const [result, setResult] = useState<CalculationResponse | null>(null);
  const [showComparison, setShowComparison] = useState(false);
  const [comparisonResult, setComparisonResult] = useState<ComparisonResponse | null>(null);
  const [selectedModel, setSelectedModel] = useState<VehicleModel | null>(null);
  const { toast } = useToast();

  const { data: parameters } = useQuery<ParameterSettings>({
    queryKey: ["/api/parameters"],
  });

  const form = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      brandId: "",
      modelId: "",
      ncmCode: "",
      fobCurrency: "USD",
      fobValue: "",
      weightKg: "",
      transportMode: "maritime",
      originId: "",
      destinationId: "",
      exchangeRate: "",
    },
  });

  const transportMode = form.watch("transportMode");
  const selectedBrandId = form.watch("brandId");

  const availableModels = useMemo(() => {
    if (!selectedBrandId) return [];
    return getVehicleModelsByBrand(selectedBrandId);
  }, [selectedBrandId]);

  const calculateMutation = useMutation({
    mutationFn: async (data: CalculationInput) => {
      const response = await apiRequest("POST", "/api/calculate", data);
      return await response.json() as CalculationResponse;
    },
    onSuccess: (data) => {
      setResult(data);
      toast({
        title: "Cálculo realizado",
        description: `Custo total: ${formatCurrency(data.breakdown.totalLandedCost)}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro no cálculo",
        description: error.message || "Não foi possível calcular os impostos",
        variant: "destructive",
      });
    },
  });

  const compareMutation = useMutation({
    mutationFn: async (data: CalculationInput) => {
      const response = await apiRequest("POST", "/api/compare", data);
      return await response.json() as ComparisonResponse;
    },
    onSuccess: (data) => {
      setComparisonResult(data);
    },
    onError: (error: Error) => {
      toast({
        title: "Erro na comparação",
        description: error.message || "Não foi possível comparar as modalidades",
        variant: "destructive",
      });
    },
  });

  const filteredOrigins = useMemo(() => {
    const mode = transportMode;
    return originLocations.filter(l => 
      mode === "air" ? l.type === "airport" : l.type === "port"
    );
  }, [transportMode]);

  const filteredDestinations = useMemo(() => {
    const mode = transportMode;
    return destinationLocations.filter(l => 
      mode === "air" ? l.type === "airport" : l.type === "port"
    );
  }, [transportMode]);

  const groupedOrigins = useMemo(() => {
    const groups: Record<string, Location[]> = {};
    filteredOrigins.forEach(loc => {
      if (!groups[loc.country]) groups[loc.country] = [];
      groups[loc.country].push(loc);
    });
    return groups;
  }, [filteredOrigins]);

  const handleBrandChange = useCallback((brandId: string) => {
    form.setValue("brandId", brandId);
    form.setValue("modelId", "");
    form.setValue("ncmCode", "");
    form.setValue("weightKg", "");
    setSelectedModel(null);
  }, [form]);

  const handleModelChange = useCallback((modelId: string) => {
    const model = vehicleModels.find(m => m.id === modelId);
    if (model) {
      setSelectedModel(model);
      form.setValue("modelId", modelId);
      form.setValue("ncmCode", model.ncmCode);
      form.setValue("weightKg", String(model.weightKg));
    }
  }, [form]);

  const onSubmit = useCallback((data: FormData) => {
    const brand = vehicleBrands.find(b => b.id === data.brandId);
    const model = vehicleModels.find(m => m.id === data.modelId);
    const productName = brand && model ? `${brand.name} ${model.name}` : "Veículo";
    
    const fobValue = parseFloat(data.fobValue);
    const exchangeRate = parseFloat(data.exchangeRate);
    
    // Convert EUR to USD if needed (for calculation purposes, we use USD as base)
    // The exchangeRate in the form is BRL/selected currency
    // We need to pass FOB in USD to the backend
    let fobValueUsd = fobValue;
    if (data.fobCurrency === "EUR" && parameters) {
      // Convert EUR to USD: EUR * (EUR/BRL) / (USD/BRL) = USD
      const eurToBrl = parameters.exchangeRateEur;
      const usdToBrl = parameters.exchangeRateUsd;
      fobValueUsd = fobValue * (eurToBrl / usdToBrl);
    }
    
    // Auto-calculate IPI criteria based on vehicle fuel type
    const fuelToEnergyMap: Record<string, "electric" | "hybrid_plugin" | "hybrid_mhev" | "gasoline" | "diesel"> = {
      electric: "electric",
      hybrid_plugin: "hybrid_plugin",
      hybrid: "hybrid_mhev",
      gasoline: "gasoline",
      diesel: "diesel",
    };
    const ipiEnergySource = model ? fuelToEnergyMap[model.fuelType] || "gasoline" : "gasoline";
    
    const input: CalculationInput = {
      productName,
      ncmCode: data.ncmCode,
      fobValueUsd,
      quantity: 1,
      weightKg: parseFloat(data.weightKg),
      transportMode: data.transportMode as TransportMode,
      originId: data.originId,
      destinationId: data.destinationId,
      exchangeRate: data.fobCurrency === "EUR" && parameters ? parameters.exchangeRateUsd : exchangeRate,
      // IPI NC 87-13 Criteria - auto-calculated based on vehicle
      ipiEnergySource,
      ipiEfficiencyLevel: "standard",
      ipiPowerLevel: "under290kw",
      ipiStructuralPerformance: "not_certified",
    };

    calculateMutation.mutate(input);
  }, [calculateMutation, parameters]);

  const handleCompare = useCallback(() => {
    if (!result) return;
    
    setShowComparison(true);
    compareMutation.mutate(result.input);
  }, [result, compareMutation]);

  const handleReset = useCallback(() => {
    form.reset();
    setResult(null);
    setSelectedModel(null);
    setComparisonResult(null);
    setShowComparison(false);
  }, [form]);

  const { user, isLoading: authLoading, isAdmin, login, register, logout, isLoggingIn, isRegistering } = useAuth();
  const [parametersOpen, setParametersOpen] = useState(false);
  const [authDialogOpen, setAuthDialogOpen] = useState(false);
  const [authTab, setAuthTab] = useState<"cliente" | "admin">("cliente");
  const [clienteTab, setClienteTab] = useState<"login" | "register">("register");
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [registerEmail, setRegisterEmail] = useState("");
  const [registerPassword, setRegisterPassword] = useState("");
  const [registerFirstName, setRegisterFirstName] = useState("");
  const [registerLastName, setRegisterLastName] = useState("");
  const [registerPhone, setRegisterPhone] = useState("");
  const [registerConfirmPassword, setRegisterConfirmPassword] = useState("");
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [showRegisterPassword, setShowRegisterPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [authError, setAuthError] = useState("");
  const [ptaxLoading, setPtaxLoading] = useState(false);
  const [ptaxInfo, setPtaxInfo] = useState<{ currency: string; rate: string; date: string } | null>(null);

  // Function to fetch PTAX from Banco Central API
  const fetchPtaxFromBCB = useCallback(async (currency: "USD" | "EUR") => {
    setPtaxLoading(true);
    try {
      // Format today's date as MM-DD-YYYY for the API
      const today = new Date();
      const formatDate = (d: Date) => {
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const year = d.getFullYear();
        return `${month}-${day}-${year}`;
      };
      
      // Try today first, then go back up to 5 days (for weekends/holidays)
      for (let i = 0; i <= 5; i++) {
        const checkDate = new Date(today);
        checkDate.setDate(checkDate.getDate() - i);
        const dateStr = formatDate(checkDate);
        
        let url: string;
        if (currency === "USD") {
          url = `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoDolarDia(dataCotacao=@dataCotacao)?@dataCotacao='${dateStr}'&$format=json`;
        } else {
          url = `https://olinda.bcb.gov.br/olinda/servico/PTAX/versao/v1/odata/CotacaoMoedaDia(moeda=@moeda,dataCotacao=@dataCotacao)?@moeda='EUR'&@dataCotacao='${dateStr}'&$format=json`;
        }
        
        const response = await fetch(url);
        if (!response.ok) continue;
        
        const data = await response.json();
        if (data.value && data.value.length > 0) {
          // Get the last quote of the day (cotacaoVenda = sell rate)
          const lastQuote = data.value[data.value.length - 1];
          const rate = lastQuote.cotacaoVenda || lastQuote.cotacaoCompra;
          if (rate) {
            form.setValue("exchangeRate", rate.toFixed(4));
            setPtaxInfo({
              currency,
              rate: rate.toFixed(4),
              date: checkDate.toLocaleDateString('pt-BR'),
            });
            return;
          }
        }
      }
      
      // If no rate found, show error
      toast({
        title: "Erro ao buscar PTAX",
        description: "Não foi possível obter a cotação do Banco Central. Tente novamente.",
        variant: "destructive",
      });
    } catch (error) {
      console.error("Error fetching PTAX:", error);
      toast({
        title: "Erro ao buscar PTAX",
        description: "Falha na conexão com o Banco Central. Verifique sua internet.",
        variant: "destructive",
      });
    } finally {
      setPtaxLoading(false);
    }
  }, [form, toast]);

  useEffect(() => {
    if (user && isAdmin) {
      setParametersOpen(true);
    }
  }, [user, isAdmin]);


  // Fetch PTAX from Banco Central on initial load
  useEffect(() => {
    const currency = form.getValues("fobCurrency") as "USD" | "EUR";
    fetchPtaxFromBCB(currency);
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    try {
      await login({ email: loginEmail, password: loginPassword });
      setAuthDialogOpen(false);
      setLoginEmail("");
      setLoginPassword("");
      toast({ title: "Login realizado", description: "Bem-vindo de volta!" });
    } catch (error: any) {
      setAuthError(error.message || "Email ou senha inválidos");
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    
    if (registerPassword !== registerConfirmPassword) {
      setAuthError("As senhas não coincidem");
      return;
    }
    
    try {
      await register({
        email: registerEmail,
        password: registerPassword,
        firstName: registerFirstName,
        lastName: registerLastName || undefined,
        phone: registerPhone || undefined,
      });
      setAuthDialogOpen(false);
      setRegisterEmail("");
      setRegisterPassword("");
      setRegisterConfirmPassword("");
      setRegisterFirstName("");
      setRegisterLastName("");
      setRegisterPhone("");
      toast({ title: "Cadastro realizado", description: "Sua conta foi criada com sucesso!" });
    } catch (error: any) {
      setAuthError(error.message || "Erro ao criar conta");
    }
  };

  const handleLogout = () => {
    logout();
    toast({ title: "Logout realizado", description: "Até logo!" });
  };

  const emailResultMutation = useMutation({
    mutationFn: async () => {
      if (!result || !user) return;
      const response = await apiRequest("POST", "/api/send-result-email", {
        result: result,
        userEmail: user.email,
        userName: user.firstName,
      });
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Email enviado",
        description: `O resultado foi enviado para ${user?.email}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Erro ao enviar email",
        description: error.message || "Não foi possível enviar o email",
        variant: "destructive",
      });
    },
  });

  const handleSendEmail = useCallback(() => {
    if (user && result) {
      emailResultMutation.mutate();
    }
  }, [user, result, emailResultMutation]);

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - Compact */}
      <div className="relative bg-gradient-to-br from-primary/10 via-background to-primary/5 border-b">
        <div className="relative max-w-6xl mx-auto px-6 lg:px-12 py-6 lg:py-8">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h1 className="text-xl lg:text-2xl font-semibold text-foreground" data-testid="heading-main">
                Importação de Veículos de Luxo
              </h1>
              <p className="text-sm text-muted-foreground mt-1" data-testid="text-pessoa-fisica">
                Pessoa Física
              </p>
            </div>
            <div className="flex items-center gap-3">
              {/* PTAX Status */}
              {ptaxInfo && (
                <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground bg-muted/50 px-3 py-1.5 rounded-md" data-testid="ptax-status">
                  <span className="text-green-600 dark:text-green-400 font-medium">PTAX Atualizado</span>
                  <span>|</span>
                  <span>{ptaxInfo.currency}: R$ {ptaxInfo.rate}</span>
                  <span className="text-muted-foreground/70">({ptaxInfo.date})</span>
                </div>
              )}
              {ptaxLoading && (
                <div className="hidden sm:flex items-center gap-2 text-xs text-muted-foreground">
                  <Loader2 className="h-3 w-3 animate-spin" />
                  <span>Buscando PTAX...</span>
                </div>
              )}
              {isAdmin && (
                <Dialog open={parametersOpen} onOpenChange={setParametersOpen}>
                  <DialogTrigger asChild>
                    <Button variant="ghost" size="sm" className="gap-2" data-testid="button-parameters">
                      <Settings className="h-4 w-4" />
                      <span className="hidden sm:inline">Parâmetros</span>
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
                    <DialogHeader>
                      <DialogTitle className="flex items-center gap-2">
                        <Settings className="h-5 w-5 text-primary" />
                        Parâmetros do Sistema
                      </DialogTitle>
                    </DialogHeader>
                    {parametersOpen && <ParameterSettingsPanel />}
                  </DialogContent>
                </Dialog>
              )}
              {authLoading ? (
                <Skeleton className="h-9 w-24" />
              ) : user ? (
                <div className="flex items-center gap-2">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm hidden sm:inline">{user.firstName || user.email}</span>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleLogout}
                    className="gap-2"
                    data-testid="button-logout"
                  >
                    <LogOut className="h-4 w-4" />
                    <span className="hidden sm:inline">Sair</span>
                  </Button>
                </div>
              ) : (
                <Dialog open={authDialogOpen} onOpenChange={(open) => { setAuthDialogOpen(open); setAuthError(""); }}>
                  <DialogTrigger asChild>
                    <Button 
                      variant="default" 
                      size="sm" 
                      className="gap-2"
                      data-testid="button-login"
                    >
                      <LogIn className="h-4 w-4" />
                      Entrar
                    </Button>
                  </DialogTrigger>
                  <DialogContent className="sm:max-w-md">
                    <DialogHeader>
                      <DialogTitle>Acesso ao Sistema</DialogTitle>
                      <DialogDescription>
                        Selecione o tipo de acesso desejado.
                      </DialogDescription>
                    </DialogHeader>
                    <Tabs value={authTab} onValueChange={(v) => { setAuthTab(v as "cliente" | "admin"); setAuthError(""); }}>
                      <TabsList className="grid w-full grid-cols-2">
                        <TabsTrigger value="cliente" data-testid="tab-cliente">
                          <User className="h-4 w-4 mr-2" />
                          Cliente
                        </TabsTrigger>
                        <TabsTrigger value="admin" data-testid="tab-admin">
                          <Settings className="h-4 w-4 mr-2" />
                          Administrador
                        </TabsTrigger>
                      </TabsList>
                      
                      {/* Cliente Tab */}
                      <TabsContent value="cliente" className="space-y-4 pt-4">
                        <Tabs value={clienteTab} onValueChange={(v) => { setClienteTab(v as "login" | "register"); setAuthError(""); }}>
                          <TabsList className="grid w-full grid-cols-2">
                            <TabsTrigger value="register" data-testid="tab-cliente-register">
                              <UserPlus className="h-4 w-4 mr-2" />
                              Cadastrar
                            </TabsTrigger>
                            <TabsTrigger value="login" data-testid="tab-cliente-login">
                              <LogIn className="h-4 w-4 mr-2" />
                              Entrar
                            </TabsTrigger>
                          </TabsList>
                          <TabsContent value="login" className="space-y-4 pt-4">
                            <p className="text-sm text-muted-foreground">
                              Acesse sua conta para receber cálculos por email.
                            </p>
                            <form onSubmit={handleLogin} className="space-y-4">
                              <div className="space-y-2">
                                <Label htmlFor="cliente-login-email">Email</Label>
                                <Input
                                  id="cliente-login-email"
                                  type="email"
                                  placeholder="seu@email.com"
                                  value={loginEmail}
                                  onChange={(e) => setLoginEmail(e.target.value)}
                                  required
                                  data-testid="input-cliente-login-email"
                                />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="cliente-login-password">Senha</Label>
                                <div className="relative">
                                  <Input
                                    id="cliente-login-password"
                                    type={showLoginPassword ? "text" : "password"}
                                    placeholder="Sua senha"
                                    value={loginPassword}
                                    onChange={(e) => setLoginPassword(e.target.value)}
                                    required
                                    className="pr-10"
                                    data-testid="input-cliente-login-password"
                                  />
                                  <Button
                                    type="button"
                                    variant="ghost"
                                    size="icon"
                                    className="absolute right-0 top-0 h-full px-3"
                                    onClick={() => setShowLoginPassword(!showLoginPassword)}
                                    data-testid="button-toggle-login-password"
                                  >
                                    {showLoginPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                  </Button>
                                </div>
                              </div>
                              {authError && (
                                <p className="text-sm text-destructive flex items-center gap-1" data-testid="text-auth-error">
                                  <AlertCircle className="h-4 w-4" />
                                  {authError}
                                </p>
                              )}
                              <Button type="submit" className="w-full" disabled={isLoggingIn} data-testid="button-submit-cliente-login">
                                {isLoggingIn ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <LogIn className="h-4 w-4 mr-2" />}
                                Entrar
                              </Button>
                            </form>
                          </TabsContent>
                          <TabsContent value="register" className="space-y-4 pt-4">
                            <p className="text-sm text-muted-foreground">
                              Cadastre-se para receber cálculos detalhados por email.
                            </p>
                            <form onSubmit={handleRegister} className="space-y-4">
                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor="register-firstName">Nome</Label>
                                  <Input
                                    id="register-firstName"
                                    placeholder="Seu nome"
                                    value={registerFirstName}
                                    onChange={(e) => setRegisterFirstName(e.target.value)}
                                    required
                                    data-testid="input-register-firstName"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="register-lastName">Sobrenome</Label>
                                  <Input
                                    id="register-lastName"
                                    placeholder="Seu sobrenome"
                                    value={registerLastName}
                                    onChange={(e) => setRegisterLastName(e.target.value)}
                                    required
                                    data-testid="input-register-lastName"
                                  />
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor="register-email">Email</Label>
                                  <Input
                                    id="register-email"
                                    type="email"
                                    placeholder="seu@email.com"
                                    value={registerEmail}
                                    onChange={(e) => setRegisterEmail(e.target.value)}
                                    required
                                    data-testid="input-register-email"
                                  />
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="register-phone">Fone/Whatsapp</Label>
                                  <Input
                                    id="register-phone"
                                    type="tel"
                                    placeholder="+55 11 99999-9999"
                                    value={registerPhone}
                                    onChange={(e) => setRegisterPhone(e.target.value)}
                                    required
                                    data-testid="input-register-phone"
                                  />
                                </div>
                              </div>
                              <div className="grid grid-cols-2 gap-3">
                                <div className="space-y-2">
                                  <Label htmlFor="register-password">Senha</Label>
                                  <div className="relative">
                                    <Input
                                      id="register-password"
                                      type={showRegisterPassword ? "text" : "password"}
                                      placeholder="Mínimo 6 caracteres"
                                      value={registerPassword}
                                      onChange={(e) => setRegisterPassword(e.target.value)}
                                      required
                                      minLength={6}
                                      className="pr-10"
                                      data-testid="input-register-password"
                                    />
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      className="absolute right-0 top-0 h-full px-3"
                                      onClick={() => setShowRegisterPassword(!showRegisterPassword)}
                                      data-testid="button-toggle-register-password"
                                    >
                                      {showRegisterPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </Button>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <Label htmlFor="register-confirm-password">Confirmar Senha</Label>
                                  <div className="relative">
                                    <Input
                                      id="register-confirm-password"
                                      type={showConfirmPassword ? "text" : "password"}
                                      placeholder="Repita a senha"
                                      value={registerConfirmPassword}
                                      onChange={(e) => setRegisterConfirmPassword(e.target.value)}
                                      required
                                      minLength={6}
                                      className="pr-10"
                                      data-testid="input-register-confirm-password"
                                    />
                                    <Button
                                      type="button"
                                      variant="ghost"
                                      size="icon"
                                      className="absolute right-0 top-0 h-full px-3"
                                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                      data-testid="button-toggle-confirm-password"
                                    >
                                      {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                                    </Button>
                                  </div>
                                </div>
                              </div>
                              {authError && (
                                <p className="text-sm text-destructive flex items-center gap-1" data-testid="text-auth-error">
                                  <AlertCircle className="h-4 w-4" />
                                  {authError}
                                </p>
                              )}
                              <Button type="submit" className="w-full" disabled={isRegistering} data-testid="button-submit-register">
                                {isRegistering ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <UserPlus className="h-4 w-4 mr-2" />}
                                Criar Conta
                              </Button>
                            </form>
                          </TabsContent>
                        </Tabs>
                      </TabsContent>
                      
                      {/* Admin Tab */}
                      <TabsContent value="admin" className="space-y-4 pt-4">
                        <p className="text-sm text-muted-foreground">
                          Acesso restrito para gerenciamento de parâmetros do sistema.
                        </p>
                        <form onSubmit={handleLogin} className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="admin-login-email">Email</Label>
                            <Input
                              id="admin-login-email"
                              type="email"
                              placeholder="admin@empresa.com"
                              value={loginEmail}
                              onChange={(e) => setLoginEmail(e.target.value)}
                              required
                              data-testid="input-admin-login-email"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="admin-login-password">Senha</Label>
                            <Input
                              id="admin-login-password"
                              type="password"
                              placeholder="Senha do administrador"
                              value={loginPassword}
                              onChange={(e) => setLoginPassword(e.target.value)}
                              required
                              data-testid="input-admin-login-password"
                            />
                          </div>
                          {authError && (
                            <p className="text-sm text-destructive flex items-center gap-1" data-testid="text-auth-error">
                              <AlertCircle className="h-4 w-4" />
                              {authError}
                            </p>
                          )}
                          <Button type="submit" className="w-full" disabled={isLoggingIn} data-testid="button-submit-admin-login">
                            {isLoggingIn ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <LogIn className="h-4 w-4 mr-2" />}
                            Entrar como Administrador
                          </Button>
                        </form>
                      </TabsContent>
                    </Tabs>
                  </DialogContent>
                </Dialog>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Calculator Section */}
      <div className="max-w-6xl mx-auto px-6 lg:px-12 py-4 lg:py-6">

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form Column */}
          <div>
            <Card className="border-card-border shadow-sm">
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-xl">
                  <FileText className="h-5 w-5 text-primary" />
                  Dados da Importação
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-3">
                    {/* Transport Mode Toggle */}
                    <FormField
                      control={form.control}
                      name="transportMode"
                      render={({ field }) => (
                        <FormItem>
                          <div className="grid grid-cols-2 gap-2">
                            <Button
                              type="button"
                              size="sm"
                              variant={field.value === "maritime" ? "default" : "outline"}
                              className="gap-2"
                              onClick={() => {
                                field.onChange("maritime");
                                form.setValue("originId", "");
                                form.setValue("destinationId", "");
                              }}
                              data-testid="button-transport-maritime"
                            >
                              <Ship className="h-4 w-4" />
                              Marítimo
                            </Button>
                            <Button
                              type="button"
                              size="sm"
                              variant="outline"
                              className="gap-2 opacity-60"
                              onClick={() => {
                                toast({
                                  title: "Modalidade não disponível",
                                  description: "O transporte aéreo ainda não está disponível. Por favor, utilize o transporte marítimo.",
                                  variant: "destructive",
                                });
                              }}
                              data-testid="button-transport-air"
                            >
                              <Plane className="h-4 w-4" />
                              Aéreo
                              <span className="text-xs">(em breve)</span>
                            </Button>
                          </div>
                        </FormItem>
                      )}
                    />

                    {/* Vehicle Brand Selection */}
                    <FormField
                      control={form.control}
                      name="brandId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Marca do Veículo</FormLabel>
                          <Select onValueChange={handleBrandChange} value={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-brand" className="h-9">
                                <div className="flex items-center gap-2">
                                  <Car className="h-4 w-4 text-muted-foreground" />
                                  <SelectValue placeholder="Selecione a marca..." />
                                </div>
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {vehicleBrands.map((brand) => (
                                <SelectItem key={brand.id} value={brand.id} data-testid={`brand-option-${brand.id}`}>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">{brand.name}</span>
                                    <span className="text-xs text-muted-foreground">({brand.country})</span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Vehicle Model Selection */}
                    <FormField
                      control={form.control}
                      name="modelId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Modelo do Veículo</FormLabel>
                          <Select 
                            onValueChange={handleModelChange} 
                            value={field.value}
                            disabled={!selectedBrandId}
                          >
                            <FormControl>
                              <SelectTrigger data-testid="select-model" className="h-9">
                                <SelectValue placeholder={selectedBrandId ? "Selecione o modelo..." : "Selecione a marca primeiro"} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {availableModels.map((model) => (
                                <SelectItem key={model.id} value={model.id} data-testid={`model-option-${model.id}`}>
                                  <div className="flex items-center gap-2">
                                    <span className="font-medium">{model.name}</span>
                                    <span className="text-xs text-muted-foreground">
                                      {getFuelTypeLabel(model.fuelType)}
                                      {model.engineCc && ` | ${model.engineCc.toLocaleString('pt-BR')}cc`}
                                      {model.powerKw && ` | ${model.powerKw}kW`}
                                      {model.batteryKwh && ` | ${model.batteryKwh}kWh`}
                                    </span>
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {selectedModel && (
                            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground bg-muted/50 p-2 rounded-md" data-testid="model-details">
                              <span>NCM: {selectedModel.ncmCode.replace(/(\d{4})(\d{2})(\d{2})/, '$1.$2.$3')}</span>
                              <span>Peso: {selectedModel.weightKg.toLocaleString('pt-BR')} kg</span>
                            </div>
                          )}
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Moeda, Câmbio, Valor FOB, Valor R$ */}
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="fobCurrency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Moeda</FormLabel>
                              <Select value={field.value} onValueChange={(value) => {
                                field.onChange(value);
                                fetchPtaxFromBCB(value as "USD" | "EUR");
                              }}>
                                <FormControl>
                                  <SelectTrigger data-testid="select-fob-currency">
                                    <SelectValue placeholder="Moeda" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="USD">USD (Dólar)</SelectItem>
                                  <SelectItem value="EUR">EUR (Euro)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={form.control}
                          name="exchangeRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Câmbio PTAX (R$/{form.watch("fobCurrency")})</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <Input 
                                    {...field} 
                                    type="number" 
                                    step="0.0001"
                                    placeholder={ptaxLoading ? "Buscando..." : "5.50"}
                                    readOnly
                                    className="bg-muted/50"
                                    data-testid="input-exchange-rate"
                                  />
                                  {ptaxLoading && (
                                    <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
                                  )}
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <FormField
                          control={form.control}
                          name="fobValue"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Valor FOB ({form.watch("fobCurrency")})</FormLabel>
                              <FormControl>
                                <div className="relative">
                                  <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                                  <Input 
                                    {...field} 
                                    type="number" 
                                    step="0.01"
                                    placeholder="0.00" 
                                    className="pl-10"
                                    data-testid="input-fob-value"
                                  />
                                </div>
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <div className="space-y-2">
                          <FormLabel>Valor FOB (R$)</FormLabel>
                          <div className="h-9 px-3 py-2 rounded-md border bg-muted/50 flex items-center" data-testid="display-fob-brl">
                            <span className="text-sm font-medium">
                              {(() => {
                                const fobValue = parseFloat(form.watch("fobValue") || "0");
                                const exchangeRate = parseFloat(form.watch("exchangeRate") || "0");
                                const fobBrl = fobValue * exchangeRate;
                                return isNaN(fobBrl) ? "R$ 0,00" : `R$ ${fobBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
                              })()}
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>


                    {/* Origin and Destination */}
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="originId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Local de Embarque</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger className="h-9" data-testid="select-origin">
                                  <SelectValue placeholder="Selecione..." />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {filteredOrigins.map((loc) => (
                                  <SelectItem key={loc.id} value={loc.id} data-testid={`origin-option-${loc.id}`}>
                                    {loc.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="destinationId"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Local de Descarga</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger className="h-9" data-testid="select-destination">
                                  <SelectValue placeholder="Selecione..." />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {filteredDestinations.map((loc) => (
                                  <SelectItem key={loc.id} value={loc.id} data-testid={`destination-option-${loc.id}`}>
                                    {loc.name} ({loc.state})
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Error display */}
                    {calculateMutation.isError && (
                      <ErrorMessage message={calculateMutation.error?.message || "Erro ao calcular impostos"} />
                    )}

                    {/* Action Buttons */}
                    <div className="flex gap-3 pt-4">
                      {user ? (
                        <Button 
                          type="submit" 
                          className="flex-1 h-12 gap-2" 
                          disabled={calculateMutation.isPending}
                          data-testid="button-calculate"
                        >
                          {calculateMutation.isPending ? (
                            <Loader2 className="h-5 w-5 animate-spin" />
                          ) : (
                            <Calculator className="h-5 w-5" />
                          )}
                          {calculateMutation.isPending ? "Calculando..." : "Calcular Impostos"}
                        </Button>
                      ) : (
                        <Button 
                          type="button"
                          className="flex-1 h-12 gap-2" 
                          onClick={() => setAuthDialogOpen(true)}
                          data-testid="button-login-to-calculate"
                        >
                          <LogIn className="h-5 w-5" />
                          Cadastre-se para Calcular
                        </Button>
                      )}
                      <Button 
                        type="button" 
                        variant="outline" 
                        onClick={handleReset}
                        className="h-12 gap-2"
                        data-testid="button-reset"
                      >
                        <RotateCcw className="h-4 w-4" />
                        Limpar
                      </Button>
                    </div>

                    {/* WhatsApp CTA Button */}
                    <Button 
                      type="button"
                      className="w-full h-12 gap-2 bg-green-600 hover:bg-green-700 text-white mt-3"
                      onClick={() => {
                        const message = encodeURIComponent(
                          `Olá! Tenho interesse em importar um veículo. ${result ? `\n\nVeículo: ${result.input.productName}\nNCM: ${result.input.ncmCode}\nValor FOB: USD ${result.input.fobValueUsd.toLocaleString('pt-BR')}\nCusto Total Estimado: R$ ${result.breakdown.totalLandedCost.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}` : ''}`
                        );
                        window.open(`https://wa.me/5511995080807?text=${message}`, '_blank');
                      }}
                      data-testid="button-whatsapp-import"
                    >
                      <SiWhatsapp className="h-5 w-5" />
                      Quero Importar
                    </Button>

                    {/* Summary Section - Shows after calculation */}
                    {result && (
                      <div className="pt-4 mt-4 border-t border-border space-y-3">
                        <div className="grid grid-cols-3 gap-3 text-sm">
                          <div className="text-center p-3 bg-muted/50 rounded-md">
                            <p className="text-muted-foreground text-xs mb-1">CIF</p>
                            <p className="font-semibold tabular-nums">{formatCurrency(result.breakdown.cifBrl)}</p>
                          </div>
                          <div className="text-center p-3 bg-primary/10 rounded-md">
                            <p className="text-muted-foreground text-xs mb-1">Impostos</p>
                            <p className="font-semibold tabular-nums text-primary">{formatCurrency(result.breakdown.totalTaxes)}</p>
                          </div>
                          <div className="text-center p-3 bg-amber-500/10 dark:bg-amber-500/20 rounded-md">
                            <p className="text-muted-foreground text-xs mb-1">Despesas</p>
                            <p className="font-semibold tabular-nums text-amber-600 dark:text-amber-400">{formatCurrency(result.breakdown.totalOperational)}</p>
                          </div>
                        </div>
                        
                        {/* Final Cost */}
                        <div className="bg-gradient-to-br from-primary to-primary/80 text-primary-foreground rounded-lg p-6 text-center">
                          <p className="text-sm opacity-90 mb-1">Custo Total Nacionalizado</p>
                          <p className="text-3xl font-bold tabular-nums" data-testid="text-total-cost">
                            {formatCurrency(result.breakdown.totalLandedCost)}
                          </p>
                          <p className="text-xs opacity-75 mt-2">
                            CIF + Impostos + Despesas Operacionais
                          </p>
                        </div>
                      </div>
                    )}
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>

          {/* Results Column */}
          <div className="lg:sticky lg:top-8 lg:self-start">
            {calculateMutation.isPending ? (
              <TaxResultCard breakdown={null} transportMode={transportMode as TransportMode} isLoading={true} />
            ) : result ? (
              <TaxResultCard 
                breakdown={result.breakdown} 
                transportMode={result.input.transportMode}
                onEmail={handleSendEmail}
                userEmail={user?.email}
                isSendingEmail={emailResultMutation.isPending}
              />
            ) : (
              <Card className="border-card-border border-dashed" data-testid="card-empty-state">
                <CardContent className="flex flex-col items-center justify-center py-16 text-center">
                  <div className="w-16 h-16 rounded-full bg-muted/50 flex items-center justify-center mb-4">
                    <Calculator className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-lg font-medium text-muted-foreground mb-2">
                    Aguardando cálculo
                  </h3>
                  <p className="text-sm text-muted-foreground max-w-[250px]">
                    Preencha os dados do produto e clique em "Calcular Impostos" para ver o resultado.
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Footer Info */}
      <footer className="border-t bg-muted/30 mt-12">
        <div className="max-w-6xl mx-auto px-6 lg:px-12 py-8">
          <div className="grid md:grid-cols-3 gap-6 text-sm text-muted-foreground">
            <div>
              <h4 className="font-semibold text-foreground mb-2">Impostos Calculados</h4>
              <ul className="space-y-1">
                <li>II - Imposto de Importação</li>
                <li>IPI - Produtos Industrializados</li>
                <li>PIS/COFINS - Importação</li>
                <li>ICMS - Estadual</li>
                <li>Taxa Siscomex</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Observações</h4>
              <p className="text-xs leading-relaxed">
                Os valores apresentados são estimativas baseadas nas alíquotas vigentes.
                Consulte um despachante aduaneiro para valores exatos.
              </p>
            </div>
            <div>
              <h4 className="font-semibold text-foreground mb-2">Sobre</h4>
              <p className="text-xs leading-relaxed">
                Esta calculadora é uma ferramenta educacional para estimativa de custos de importação.
                As alíquotas podem variar conforme acordos comerciais e legislação vigente.
              </p>
            </div>
          </div>
          <div className="mt-8 pt-6 border-t text-center text-xs text-muted-foreground">
            Calculadora de Importação Brasil - {new Date().getFullYear()}
          </div>
        </div>
      </footer>
    </div>
  );
}
