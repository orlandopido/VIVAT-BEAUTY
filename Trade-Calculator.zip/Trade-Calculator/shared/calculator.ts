import {
  type CalculationInput,
  type TaxBreakdown,
  type OperationalExpenses,
  type NcmCode,
  type ParameterSettings,
  type IpiBreakdown,
  type IpiEnergySource,
  type IpiEfficiencyLevel,
  type IpiPowerLevel,
  type IpiStructuralPerformance,
  ncmCodes,
  originLocations,
  destinationLocations,
  getIcmsRate,
  freightRates,
  siscomexFees,
  insuranceRate,
  operationalDefaults,
  defaultParameters,
} from "./schema";

// Get country key from origin location
function getCountryKey(originId: string): "china" | "korea" | "usa" {
  const location = originLocations.find(l => l.id === originId);
  if (!location) return "china";
  
  switch (location.country) {
    case "China": return "china";
    case "Coreia do Sul": return "korea";
    case "Estados Unidos": return "usa";
    default: return "china";
  }
}

// Calculate freight cost based on weight and transport mode
export function calculateFreight(
  weightKg: number,
  transportMode: "air" | "maritime",
  originId: string,
  exchangeRate: number
): number {
  const countryKey = getCountryKey(originId);
  const ratePerKg = freightRates[transportMode][countryKey];
  const freightUsd = weightKg * ratePerKg;
  
  // Minimum freight for maritime
  if (transportMode === "maritime") {
    const minFreight = 300; // USD minimum for maritime
    return Math.max(freightUsd, minFreight) * exchangeRate;
  }
  
  return freightUsd * exchangeRate;
}

// Calculate insurance based on FOB + Freight
export function calculateInsurance(fobBrl: number, freightBrl: number): number {
  return (fobBrl + freightBrl) * (insuranceRate / 100);
}

// Get NCM code data
export function getNcmData(ncmCode: string): NcmCode | undefined {
  return ncmCodes.find(n => n.code === ncmCode);
}

// Search NCM codes by description or code
export function searchNcmCodes(query: string): NcmCode[] {
  const normalizedQuery = query.toLowerCase().trim();
  if (!normalizedQuery) return ncmCodes.slice(0, 10);
  
  return ncmCodes.filter(n => 
    n.code.includes(normalizedQuery) || 
    n.description.toLowerCase().includes(normalizedQuery)
  ).slice(0, 10);
}

// Calculate IPI rate using NC 87-13 criteria (Decreto nº 12.549/2025)
export function calculateIpiNc8713(
  baseRate: number,
  energySource: IpiEnergySource = "gasoline",
  efficiencyLevel: IpiEfficiencyLevel = "standard",
  powerLevel: IpiPowerLevel = "under290kw",
  structuralPerformance: IpiStructuralPerformance = "not_certified"
): IpiBreakdown {
  // Critério 1 - Fonte de Energia/Propulsão
  let criterio1Adjustment = 0;
  switch (energySource) {
    case "electric":
      criterio1Adjustment = -6.3; // Elétrico puro - redução máxima
      break;
    case "hybrid_plugin":
      criterio1Adjustment = -3.0; // Híbrido plug-in - redução intermediária
      break;
    case "hybrid_mhev":
      criterio1Adjustment = 6.5; // Híbrido leve (MHEV) - acréscimo
      break;
    case "gasoline":
    case "diesel":
      criterio1Adjustment = 6.5; // Combustíveis fósseis - acréscimo
      break;
  }

  // Critério 2 - Eficiência Energética
  let criterio2Adjustment = 0;
  switch (efficiencyLevel) {
    case "high":
      criterio2Adjustment = -2.0; // Alta eficiência - redução
      break;
    case "standard":
      criterio2Adjustment = 0; // Padrão - sem ajuste
      break;
    case "low":
      criterio2Adjustment = 2.0; // Baixa eficiência - acréscimo
      break;
  }

  // Critério 3 - Potência do Motor
  let criterio3Adjustment = 0;
  if (powerLevel === "over290kw") {
    criterio3Adjustment = 6.5; // Potência > 290 kW - acréscimo
  }

  // Critério 4 - Desempenho Estrutural
  let criterio4Adjustment = 0;
  if (structuralPerformance === "certified") {
    criterio4Adjustment = -1.0; // Certificado (Euro NCAP, IIHS, etc.) - redução
  }

  // Critério 5 - Reciclabilidade (sempre 0 para pessoa física)
  const criterio5Adjustment = 0;

  // Cálculo final - soma algébrica (não pode ser inferior a 0%)
  const finalRate = Math.max(
    0,
    baseRate + criterio1Adjustment + criterio2Adjustment + criterio3Adjustment + criterio4Adjustment + criterio5Adjustment
  );

  return {
    baseRate,
    criterio1Adjustment,
    criterio2Adjustment,
    criterio3Adjustment,
    criterio4Adjustment,
    criterio5Adjustment,
    finalRate,
  };
}

// Calculate operational expenses using admin parameters
export function calculateOperationalExpenses(
  input: CalculationInput,
  cifBrl: number,
  freightBrl: number,
  params: ParameterSettings = defaultParameters
): OperationalExpenses {
  const common = operationalDefaults.common;
  
  // AFRMM (only for maritime, using parameter percentage)
  const afrmm = input.transportMode === "maritime" 
    ? freightBrl * (params.afrmmPercent / 100) 
    : 0;
  
  // THC / Capatazias from parameters
  const thc = params.thcBrl;
  
  // Primary storage (% of CIF) from parameters
  const primaryStorage = cifBrl * (params.storagePrimaryPercent / 100);
  
  // Removal fee from parameters
  const removalFee = params.removalFeeBrl;
  
  // Secondary storage (EADI) from parameters
  const secondaryStorage = params.storageSecondaryBrl;
  
  // Customs broker (despachante) - use custom rate from input or from parameters
  const brokerRate = input.customsbrokerRate ?? params.customsBrokerPercent;
  const customsBroker = cifBrl * (brokerRate / 100);
  
  // Customs broker union (S.D.A) from parameters
  const customsBrokerUnion = params.sdaBrl;
  
  // Maritime agency / cargo agent from parameters
  const cargoAgent = params.maritimeAgencyBrl;
  
  // Domestic transport from parameters
  const domesticTransport = params.roadTransportBrl;
  
  // Import license (optional) - use default from operationalDefaults
  const importLicense = input.includeImportLicense ? common.importLicense : 0;
  
  // GRU/CAT (for vehicle imports) - use default from operationalDefaults
  const isVehicle = input.ncmCode.startsWith("8703") || input.ncmCode.startsWith("8704");
  const gruCat = isVehicle ? common.gruCat : 0;
  
  // DENATRAN (for vehicles) from parameters
  const denatran = (isVehicle && input.includeDenatran) ? params.denatranBrl : 0;
  
  const totalOperational = afrmm + thc + primaryStorage + removalFee + secondaryStorage +
    customsBroker + customsBrokerUnion + cargoAgent + domesticTransport +
    importLicense + gruCat + denatran;
  
  return {
    afrmm,
    thc,
    primaryStorage,
    removalFee,
    secondaryStorage,
    customsBroker,
    customsBrokerUnion,
    cargoAgent,
    domesticTransport,
    importLicense,
    gruCat,
    denatran,
    totalOperational,
  };
}

// Main calculation function - uses admin parameters for freight, insurance, and operational costs
export function calculateImportTaxes(
  input: CalculationInput,
  params: ParameterSettings = defaultParameters
): TaxBreakdown {
  const ncmData = getNcmData(input.ncmCode);
  
  if (!ncmData) {
    throw new Error(`NCM code ${input.ncmCode} not found`);
  }
  
  // Get destination state for ICMS
  const destination = destinationLocations.find(l => l.id === input.destinationId);
  const stateCode = destination?.state ?? "SP";
  const icmsRate = getIcmsRate(stateCode);
  
  // FOB in BRL (quantity is always 1 for vehicles)
  const fobBrl = input.fobValueUsd * input.quantity * input.exchangeRate;
  
  // Freight in BRL - use parameter value (maritimeFreightBrl) for maritime
  let freightBrl: number;
  if (input.freightValueBrl !== undefined) {
    freightBrl = input.freightValueBrl;
  } else if (input.transportMode === "maritime") {
    freightBrl = params.maritimeFreightBrl;
  } else {
    const totalWeight = input.weightKg * input.quantity;
    freightBrl = calculateFreight(totalWeight, input.transportMode, input.originId, input.exchangeRate);
  }
  
  // Insurance in BRL - calculate as percentage of vehicle value (FOB in R$)
  const insuranceBrl = fobBrl * (params.insurancePercent / 100);
  
  // CIF (Cost, Insurance, Freight)
  const cifBrl = fobBrl + freightBrl + insuranceBrl;
  
  // II - Imposto de Importação (base: CIF)
  const iiValue = cifBrl * (ncmData.iiRate / 100);
  
  // IPI - Imposto sobre Produtos Industrializados (NC 87-13 - Decreto nº 12.549/2025)
  // Check if vehicle NCM (8703.xx or 8704.xx) to apply NC 87-13
  const isVehicleNcm = input.ncmCode.startsWith("8703") || input.ncmCode.startsWith("8704");
  
  let ipiBreakdown: IpiBreakdown | undefined;
  let effectiveIpiRate = ncmData.ipiRate;
  
  if (isVehicleNcm) {
    // Apply NC 87-13 criteria for vehicles
    ipiBreakdown = calculateIpiNc8713(
      ncmData.ipiRate,
      input.ipiEnergySource || "gasoline",
      input.ipiEfficiencyLevel || "standard",
      input.ipiPowerLevel || "under290kw",
      input.ipiStructuralPerformance || "not_certified"
    );
    effectiveIpiRate = ipiBreakdown.finalRate;
  }
  
  const ipiBase = cifBrl + iiValue;
  const ipiValue = ipiBase * (effectiveIpiRate / 100);
  
  // PIS-Importação (base: Valor Aduaneiro = CIF - Lei 10.865/2004 Art. 7º)
  const pisBase = cifBrl;
  const pisValue = pisBase * (ncmData.pisRate / 100);
  
  // COFINS-Importação (base: Valor Aduaneiro = CIF - Lei 10.865/2004 Art. 7º)
  const cofinsBase = cifBrl;
  const cofinsValue = cofinsBase * (ncmData.cofinsRate / 100);
  
  // Taxa Siscomex
  const siscomexFee = siscomexFees[input.transportMode];
  
  // ICMS calculation (complex - uses "por dentro" method)
  // Base ICMS = (CIF + II + IPI + PIS + COFINS + Siscomex) / (1 - ICMS rate)
  const preIcmsTotal = cifBrl + iiValue + ipiValue + pisValue + cofinsValue + siscomexFee;
  const icmsBase = preIcmsTotal / (1 - icmsRate / 100);
  const icmsValue = icmsBase * (icmsRate / 100);
  
  // Total taxes
  const totalTaxes = iiValue + ipiValue + pisValue + cofinsValue + siscomexFee + icmsValue;
  
  // Calculate operational expenses using parameters
  const operationalExpenses = calculateOperationalExpenses(input, cifBrl, freightBrl, params);
  const totalOperational = operationalExpenses.totalOperational;
  
  // Total landed cost (CIF + taxes + operational)
  const totalLandedCost = cifBrl + totalTaxes + totalOperational;
  
  return {
    fobBrl,
    freightBrl,
    insuranceBrl,
    cifBrl,
    iiValue,
    iiRate: ncmData.iiRate,
    ipiValue,
    ipiRate: effectiveIpiRate,
    ipiBreakdown,
    pisValue,
    pisRate: ncmData.pisRate,
    cofinsValue,
    cofinsRate: ncmData.cofinsRate,
    siscomexFee,
    icmsValue,
    icmsRate,
    totalTaxes,
    operationalExpenses,
    totalOperational,
    totalLandedCost,
  };
}

// Format currency in BRL with R$ symbol
export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}

// Format currency in BRL without R$ symbol (just the number)
export function formatCurrencyValue(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(value);
}

// Format percentage
export function formatPercentage(value: number): string {
  return `${value.toFixed(2)}%`;
}
