import { z } from "zod";

// Export auth models for Replit Auth
export * from "./models/auth";

// System Parameters for calculations
export const parameterSettingsSchema = z.object({
  exchangeRateUsd: z.number().positive("Taxa de câmbio USD deve ser positiva"),
  exchangeRateEur: z.number().positive("Taxa de câmbio EUR deve ser positiva"),
  autoExchangeRate: z.boolean().default(false),
  maritimeFreightUsd: z.number().min(0, "Frete marítimo USD deve ser positivo"),
  maritimeFreightBrl: z.number().min(0, "Frete marítimo BRL deve ser positivo"),
  insurancePercent: z.number().min(0).max(100, "Seguro deve ser entre 0 e 100"),
  afrmmPercent: z.number().min(0).max(100, "AFRMM deve ser entre 0 e 100"),
  customsClearanceBrl: z.number().min(0, "Desembaraço aduaneiro deve ser positivo"),
  maritimeAgencyBrl: z.number().min(0, "Agência marítima deve ser positivo"),
  roadTransportBrl: z.number().min(0, "Transporte rodoviário deve ser positivo"),
  thcBrl: z.number().min(0, "THC deve ser positivo"),
  storagePrimaryPercent: z.number().min(0).max(100, "Armazenagem primária deve ser entre 0 e 100"),
  storageSecondaryBrl: z.number().min(0, "Armazenagem secundária deve ser positivo"),
  removalFeeBrl: z.number().min(0, "Taxa de remoção deve ser positivo"),
  customsBrokerPercent: z.number().min(0).max(100, "Despachante deve ser entre 0 e 100"),
  sdaBrl: z.number().min(0, "SDA deve ser positivo"),
  denatranBrl: z.number().min(0, "DENATRAN deve ser positivo"),
  updatedAt: z.string().optional(),
});

export type ParameterSettings = z.infer<typeof parameterSettingsSchema>;

// Default parameter values
export const defaultParameters: ParameterSettings = {
  exchangeRateUsd: 5.5,
  exchangeRateEur: 6.0,
  autoExchangeRate: false,
  maritimeFreightUsd: 2500,
  maritimeFreightBrl: 15000,
  insurancePercent: 0.5,
  afrmmPercent: 8,
  customsClearanceBrl: 2500,
  maritimeAgencyBrl: 1500,
  roadTransportBrl: 3500,
  thcBrl: 941,
  storagePrimaryPercent: 3,
  storageSecondaryBrl: 2800,
  removalFeeBrl: 4200,
  customsBrokerPercent: 2.5,
  sdaBrl: 2162,
  denatranBrl: 4000,
};

// NCM Code with tax rates
export interface NcmCode {
  code: string;
  description: string;
  iiRate: number; // Imposto de Importação %
  ipiRate: number; // IPI %
  pisRate: number; // PIS-Importação %
  cofinsRate: number; // COFINS-Importação %
}

// Location (ports and airports)
export interface Location {
  id: string;
  name: string;
  code: string;
  country: string;
  type: "port" | "airport";
  state?: string; // For Brazilian locations
}

// Transport mode
export type TransportMode = "air" | "maritime";

// IPI NC 87-13 Criteria Types (Decreto nº 12.549/2025)
export type IpiEnergySource = "electric" | "hybrid_plugin" | "hybrid_mhev" | "gasoline" | "diesel";
export type IpiEfficiencyLevel = "high" | "standard" | "low";
export type IpiPowerLevel = "under290kw" | "over290kw";
export type IpiStructuralPerformance = "certified" | "not_certified";
export type IpiRecyclability = "compliant" | "not_applicable";

// IPI NC 87-13 Criteria Input
export interface IpiCriteria {
  energySource: IpiEnergySource; // Critério 1 - Fonte de Energia/Propulsão
  efficiencyLevel: IpiEfficiencyLevel; // Critério 2 - Eficiência Energética
  powerLevel: IpiPowerLevel; // Critério 3 - Potência do Motor (> 290kW)
  structuralPerformance: IpiStructuralPerformance; // Critério 4 - Desempenho Estrutural
  recyclability: IpiRecyclability; // Critério 5 - Reciclabilidade (sempre não aplicável para PF)
}

// IPI NC 87-13 Breakdown Result
export interface IpiBreakdown {
  baseRate: number; // Alíquota base TIPI
  criterio1Adjustment: number; // Critério 1 - Energia (+/- p.p.)
  criterio2Adjustment: number; // Critério 2 - Eficiência (-2.0 p.p. se eficiente)
  criterio3Adjustment: number; // Critério 3 - Potência (+6.5 p.p. se > 290kW)
  criterio4Adjustment: number; // Critério 4 - Estrutural (-1.0 p.p. se certificado)
  criterio5Adjustment: number; // Critério 5 - Reciclabilidade (0 para PF)
  finalRate: number; // Alíquota final calculada
}

// Calculation input
export const calculationInputSchema = z.object({
  productName: z.string().min(1, "Nome do produto é obrigatório"),
  ncmCode: z.string().min(8, "Código NCM inválido").max(10),
  fobValueUsd: z.number().positive("Valor FOB deve ser positivo"),
  quantity: z.number().int().positive("Quantidade deve ser positiva"),
  weightKg: z.number().positive("Peso deve ser positivo"),
  transportMode: z.enum(["air", "maritime"]),
  originId: z.string().min(1, "Local de embarque é obrigatório"),
  destinationId: z.string().min(1, "Local de descarga é obrigatório"),
  exchangeRate: z.number().positive("Taxa de câmbio deve ser positiva"),
  // IPI NC 87-13 Criteria (Decreto nº 12.549/2025)
  ipiEnergySource: z.enum(["electric", "hybrid_plugin", "hybrid_mhev", "gasoline", "diesel"]).optional(),
  ipiEfficiencyLevel: z.enum(["high", "standard", "low"]).optional(),
  ipiPowerLevel: z.enum(["under290kw", "over290kw"]).optional(),
  ipiStructuralPerformance: z.enum(["certified", "not_certified"]).optional(),
  // Optional operational expenses (user can override defaults)
  customsbrokerRate: z.number().min(0).max(10).optional(), // % for customs broker (despachante)
  includeImportLicense: z.boolean().optional(), // Licença de Importação
  includeDenatran: z.boolean().optional(), // For vehicles only
  freightValueBrl: z.number().min(0).optional(), // Manual freight override in BRL
});

export type CalculationInput = z.infer<typeof calculationInputSchema>;

// Operational expenses breakdown
export interface OperationalExpenses {
  afrmm: number; // Adicional de Frete para Renovação da Marinha Mercante (8% of maritime freight)
  thc: number; // Terminal Handling Charge / Capatazias
  primaryStorage: number; // Armazenagem Zona Primária
  removalFee: number; // Remoção para Zona Secundária
  secondaryStorage: number; // Armazenagem Zona Secundária (EADI)
  customsBroker: number; // Despachante Aduaneiro
  customsBrokerUnion: number; // S.D.A - Sindicato Despachantes Aduaneiros
  cargoAgent: number; // Agente de Carga
  domesticTransport: number; // Transporte Rodoviário / Entrega
  importLicense: number; // Licença de Importação (MDIC/IBAMA)
  gruCat: number; // GRU/CAT
  denatran: number; // DENATRAN (veículos)
  totalOperational: number;
}

// Tax breakdown result
export interface TaxBreakdown {
  fobBrl: number;
  freightBrl: number;
  insuranceBrl: number;
  cifBrl: number;
  iiValue: number;
  iiRate: number;
  ipiValue: number;
  ipiRate: number;
  ipiBreakdown?: IpiBreakdown; // Detailed IPI NC 87-13 breakdown
  pisValue: number;
  pisRate: number;
  cofinsValue: number;
  cofinsRate: number;
  siscomexFee: number;
  icmsValue: number;
  icmsRate: number;
  totalTaxes: number;
  operationalExpenses: OperationalExpenses;
  totalOperational: number;
  totalLandedCost: number;
}

// Full calculation result
export interface CalculationResult {
  id: string;
  input: CalculationInput;
  ncmDescription: string;
  breakdown: TaxBreakdown;
  createdAt: string;
}

// Brazilian states with ICMS rates
export interface BrazilianState {
  code: string;
  name: string;
  icmsRate: number;
}

// Fuel types for vehicles
export type FuelType = "electric" | "hybrid_plugin" | "hybrid" | "gasoline" | "diesel";

// Vehicle brand
export interface VehicleBrand {
  id: string;
  name: string;
  country: string;
}

// Vehicle model with characteristics
export interface VehicleModel {
  id: string;
  brandId: string;
  name: string;
  fuelType: FuelType;
  engineCc?: number; // Engine displacement in cc (null for electric)
  batteryKwh?: number; // Battery capacity for electric/hybrid
  powerKw?: number; // Power in kW
  weightKg: number; // Approximate weight
  ncmCode: string;
}

// Vehicle brands database
export const vehicleBrands: VehicleBrand[] = [
  { id: "tesla", name: "Tesla", country: "Estados Unidos" },
  { id: "ferrari", name: "Ferrari", country: "Itália" },
  { id: "lamborghini", name: "Lamborghini", country: "Itália" },
  { id: "porsche", name: "Porsche", country: "Alemanha" },
  { id: "bmw", name: "BMW", country: "Alemanha" },
  { id: "mercedes", name: "Mercedes-Benz", country: "Alemanha" },
  { id: "audi", name: "Audi", country: "Alemanha" },
  { id: "maserati", name: "Maserati", country: "Itália" },
  { id: "bentley", name: "Bentley", country: "Reino Unido" },
  { id: "rolls_royce", name: "Rolls-Royce", country: "Reino Unido" },
  { id: "mclaren", name: "McLaren", country: "Reino Unido" },
  { id: "aston_martin", name: "Aston Martin", country: "Reino Unido" },
  { id: "byd", name: "BYD", country: "China" },
  { id: "toyota", name: "Toyota", country: "Japão" },
  { id: "ford", name: "Ford", country: "Estados Unidos" },
  { id: "chevrolet", name: "Chevrolet", country: "Estados Unidos" },
  { id: "rivian", name: "Rivian", country: "Estados Unidos" },
  { id: "lucid", name: "Lucid", country: "Estados Unidos" },
  { id: "volvo", name: "Volvo", country: "Suécia" },
  { id: "jaguar", name: "Jaguar", country: "Reino Unido" },
  { id: "land_rover", name: "Land Rover", country: "Reino Unido" },
  { id: "hyundai", name: "Hyundai", country: "Coreia do Sul" },
  { id: "kia", name: "Kia", country: "Coreia do Sul" },
];

// Vehicle models database with NCM mapping
export const vehicleModels: VehicleModel[] = [
  // Tesla (100% Elétricos)
  { id: "tesla-model-3", brandId: "tesla", name: "Model 3", fuelType: "electric", batteryKwh: 60, weightKg: 1847, ncmCode: "87038000" },
  { id: "tesla-model-y", brandId: "tesla", name: "Model Y", fuelType: "electric", batteryKwh: 75, weightKg: 2003, ncmCode: "87038000" },
  { id: "tesla-model-s", brandId: "tesla", name: "Model S", fuelType: "electric", batteryKwh: 100, weightKg: 2162, ncmCode: "87038000" },
  { id: "tesla-model-x", brandId: "tesla", name: "Model X", fuelType: "electric", batteryKwh: 100, weightKg: 2459, ncmCode: "87038000" },
  { id: "tesla-cybertruck", brandId: "tesla", name: "Cybertruck", fuelType: "electric", batteryKwh: 123, weightKg: 3104, ncmCode: "87038000" },
  
  // BYD (Elétricos e Híbridos)
  { id: "byd-dolphin", brandId: "byd", name: "Dolphin", fuelType: "electric", batteryKwh: 45, weightKg: 1520, ncmCode: "87038000" },
  { id: "byd-seal", brandId: "byd", name: "Seal", fuelType: "electric", batteryKwh: 82, weightKg: 2150, ncmCode: "87038000" },
  { id: "byd-han", brandId: "byd", name: "Han EV", fuelType: "electric", batteryKwh: 85, weightKg: 2200, ncmCode: "87038000" },
  { id: "byd-tang", brandId: "byd", name: "Tang EV", fuelType: "electric", batteryKwh: 86, weightKg: 2510, ncmCode: "87038000" },
  { id: "byd-song-plus", brandId: "byd", name: "Song Plus DMI", fuelType: "hybrid_plugin", engineCc: 1500, batteryKwh: 18, weightKg: 1950, ncmCode: "87036000" },
  
  // BMW (Elétricos, Híbridos e Combustão)
  { id: "bmw-ix", brandId: "bmw", name: "iX", fuelType: "electric", batteryKwh: 105, weightKg: 2440, ncmCode: "87038000" },
  { id: "bmw-i4", brandId: "bmw", name: "i4", fuelType: "electric", batteryKwh: 84, weightKg: 2125, ncmCode: "87038000" },
  { id: "bmw-i7", brandId: "bmw", name: "i7", fuelType: "electric", batteryKwh: 102, weightKg: 2715, ncmCode: "87038000" },
  { id: "bmw-x5-45e", brandId: "bmw", name: "X5 xDrive45e", fuelType: "hybrid_plugin", engineCc: 2998, batteryKwh: 24, weightKg: 2510, ncmCode: "87036000" },
  { id: "bmw-330i", brandId: "bmw", name: "330i", fuelType: "gasoline", engineCc: 1998, weightKg: 1540, ncmCode: "87032290" },
  { id: "bmw-m3", brandId: "bmw", name: "M3 Competition", fuelType: "gasoline", engineCc: 2993, weightKg: 1730, ncmCode: "87032290" },
  { id: "bmw-m5", brandId: "bmw", name: "M5", fuelType: "gasoline", engineCc: 4395, weightKg: 1970, ncmCode: "87032410" },
  
  // Mercedes-Benz
  { id: "mercedes-eqs", brandId: "mercedes", name: "EQS", fuelType: "electric", batteryKwh: 108, weightKg: 2480, ncmCode: "87038000" },
  { id: "mercedes-eqe", brandId: "mercedes", name: "EQE", fuelType: "electric", batteryKwh: 90, weightKg: 2355, ncmCode: "87038000" },
  { id: "mercedes-eqb", brandId: "mercedes", name: "EQB", fuelType: "electric", batteryKwh: 66, weightKg: 2175, ncmCode: "87038000" },
  { id: "mercedes-gle-350e", brandId: "mercedes", name: "GLE 350e", fuelType: "hybrid_plugin", engineCc: 1991, batteryKwh: 31, weightKg: 2510, ncmCode: "87036000" },
  { id: "mercedes-c300", brandId: "mercedes", name: "C 300", fuelType: "gasoline", engineCc: 1991, weightKg: 1550, ncmCode: "87032290" },
  { id: "mercedes-s500", brandId: "mercedes", name: "S 500", fuelType: "gasoline", engineCc: 2999, weightKg: 2065, ncmCode: "87032290" },
  { id: "mercedes-amg-gt63", brandId: "mercedes", name: "AMG GT 63 S", fuelType: "gasoline", engineCc: 3982, weightKg: 2045, ncmCode: "87032410" },
  
  // Porsche
  { id: "porsche-taycan", brandId: "porsche", name: "Taycan", fuelType: "electric", batteryKwh: 93, weightKg: 2305, ncmCode: "87038000" },
  { id: "porsche-cayenne-ehybrid", brandId: "porsche", name: "Cayenne E-Hybrid", fuelType: "hybrid_plugin", engineCc: 2995, batteryKwh: 17, weightKg: 2310, ncmCode: "87036000" },
  { id: "porsche-911", brandId: "porsche", name: "911 Carrera", fuelType: "gasoline", engineCc: 2981, weightKg: 1505, ncmCode: "87032290" },
  { id: "porsche-911-turbo", brandId: "porsche", name: "911 Turbo S", fuelType: "gasoline", engineCc: 3745, weightKg: 1640, ncmCode: "87032410" },
  
  // Ford
  { id: "ford-mustang-mach-e", brandId: "ford", name: "Mustang Mach-E", fuelType: "electric", batteryKwh: 91, weightKg: 2100, ncmCode: "87038000" },
  { id: "ford-f150-lightning", brandId: "ford", name: "F-150 Lightning", fuelType: "electric", batteryKwh: 131, weightKg: 2948, ncmCode: "87038000" },
  { id: "ford-mustang-gt", brandId: "ford", name: "Mustang GT", fuelType: "gasoline", engineCc: 5038, weightKg: 1743, ncmCode: "87032410" },
  
  // Chevrolet
  { id: "chevy-bolt-euv", brandId: "chevrolet", name: "Bolt EUV", fuelType: "electric", batteryKwh: 65, weightKg: 1679, ncmCode: "87038000" },
  { id: "chevy-silverado-ev", brandId: "chevrolet", name: "Silverado EV", fuelType: "electric", batteryKwh: 200, weightKg: 4173, ncmCode: "87038000" },
  { id: "chevy-camaro-ss", brandId: "chevrolet", name: "Camaro SS", fuelType: "gasoline", engineCc: 6162, weightKg: 1659, ncmCode: "87032410" },
  { id: "chevy-corvette", brandId: "chevrolet", name: "Corvette Stingray", fuelType: "gasoline", engineCc: 6162, weightKg: 1527, ncmCode: "87032410" },
  
  // Rivian
  { id: "rivian-r1t", brandId: "rivian", name: "R1T", fuelType: "electric", batteryKwh: 135, weightKg: 3220, ncmCode: "87038000" },
  { id: "rivian-r1s", brandId: "rivian", name: "R1S", fuelType: "electric", batteryKwh: 135, weightKg: 3247, ncmCode: "87038000" },
  
  // Lucid
  { id: "lucid-air", brandId: "lucid", name: "Air", fuelType: "electric", batteryKwh: 112, weightKg: 2360, ncmCode: "87038000" },
  { id: "lucid-gravity", brandId: "lucid", name: "Gravity", fuelType: "electric", batteryKwh: 113, weightKg: 2700, ncmCode: "87038000" },
  
  // Toyota
  { id: "toyota-bz4x", brandId: "toyota", name: "bZ4X", fuelType: "electric", batteryKwh: 72, weightKg: 1920, ncmCode: "87038000" },
  { id: "toyota-prius-prime", brandId: "toyota", name: "Prius Prime", fuelType: "hybrid_plugin", engineCc: 1798, batteryKwh: 13, weightKg: 1545, ncmCode: "87036000" },
  { id: "toyota-rav4-prime", brandId: "toyota", name: "RAV4 Prime", fuelType: "hybrid_plugin", engineCc: 2487, batteryKwh: 18, weightKg: 2000, ncmCode: "87036000" },
  { id: "toyota-supra", brandId: "toyota", name: "GR Supra", fuelType: "gasoline", engineCc: 2998, weightKg: 1542, ncmCode: "87032290" },
  
  // Volvo
  { id: "volvo-ex30", brandId: "volvo", name: "EX30", fuelType: "electric", batteryKwh: 69, weightKg: 1830, ncmCode: "87038000" },
  { id: "volvo-ex90", brandId: "volvo", name: "EX90", fuelType: "electric", batteryKwh: 111, weightKg: 2818, ncmCode: "87038000" },
  { id: "volvo-xc60-recharge", brandId: "volvo", name: "XC60 Recharge", fuelType: "hybrid_plugin", engineCc: 1969, batteryKwh: 18, weightKg: 2177, ncmCode: "87036000" },
  
  // Jaguar
  { id: "jaguar-i-pace", brandId: "jaguar", name: "I-PACE", fuelType: "electric", batteryKwh: 90, weightKg: 2208, ncmCode: "87038000" },
  { id: "jaguar-f-type", brandId: "jaguar", name: "F-TYPE R", fuelType: "gasoline", engineCc: 5000, weightKg: 1770, ncmCode: "87032410" },
  
  // Land Rover
  { id: "lr-defender-130", brandId: "land_rover", name: "Defender 130", fuelType: "diesel", engineCc: 2996, weightKg: 2680, ncmCode: "87033290" },
  { id: "lr-range-rover-phev", brandId: "land_rover", name: "Range Rover P510e", fuelType: "hybrid_plugin", engineCc: 2996, batteryKwh: 38, weightKg: 2710, ncmCode: "87036000" },
  
  // Hyundai
  { id: "hyundai-ioniq5", brandId: "hyundai", name: "IONIQ 5", fuelType: "electric", batteryKwh: 77, weightKg: 2020, ncmCode: "87038000" },
  { id: "hyundai-ioniq6", brandId: "hyundai", name: "IONIQ 6", fuelType: "electric", batteryKwh: 77, weightKg: 1985, ncmCode: "87038000" },
  
  // Kia
  { id: "kia-ev6", brandId: "kia", name: "EV6", fuelType: "electric", batteryKwh: 77, weightKg: 2055, ncmCode: "87038000" },
  { id: "kia-ev9", brandId: "kia", name: "EV9", fuelType: "electric", batteryKwh: 100, weightKg: 2585, ncmCode: "87038000" },
  
  // Audi
  { id: "audi-etron-gt", brandId: "audi", name: "e-tron GT", fuelType: "electric", batteryKwh: 93, weightKg: 2347, ncmCode: "87038000" },
  { id: "audi-q8-etron", brandId: "audi", name: "Q8 e-tron", fuelType: "electric", batteryKwh: 114, weightKg: 2585, ncmCode: "87038000" },
  { id: "audi-q5-tfsi-e", brandId: "audi", name: "Q5 TFSI e", fuelType: "hybrid_plugin", engineCc: 1984, batteryKwh: 17, weightKg: 2065, ncmCode: "87036000" },
  { id: "audi-rs6", brandId: "audi", name: "RS 6 Avant", fuelType: "gasoline", engineCc: 3996, weightKg: 2075, ncmCode: "87032410" },
  { id: "audi-r8", brandId: "audi", name: "R8 V10", fuelType: "gasoline", engineCc: 5204, weightKg: 1680, ncmCode: "87032410" },
  
  // Ferrari
  { id: "ferrari-296-gtb", brandId: "ferrari", name: "296 GTB", fuelType: "hybrid_plugin", engineCc: 2992, batteryKwh: 7.45, powerKw: 610, weightKg: 1470, ncmCode: "87036000" },
  { id: "ferrari-sf90", brandId: "ferrari", name: "SF90 Stradale", fuelType: "hybrid_plugin", engineCc: 3990, batteryKwh: 7.9, powerKw: 735, weightKg: 1570, ncmCode: "87036000" },
  { id: "ferrari-roma", brandId: "ferrari", name: "Roma", fuelType: "gasoline", engineCc: 3855, powerKw: 456, weightKg: 1472, ncmCode: "87032410" },
  { id: "ferrari-812", brandId: "ferrari", name: "812 Superfast", fuelType: "gasoline", engineCc: 6496, powerKw: 588, weightKg: 1525, ncmCode: "87032410" },
  { id: "ferrari-purosangue", brandId: "ferrari", name: "Purosangue", fuelType: "gasoline", engineCc: 6496, powerKw: 533, weightKg: 2033, ncmCode: "87032410" },
  { id: "ferrari-f8", brandId: "ferrari", name: "F8 Tributo", fuelType: "gasoline", engineCc: 3902, powerKw: 530, weightKg: 1330, ncmCode: "87032410" },
  
  // Lamborghini
  { id: "lambo-revuelto", brandId: "lamborghini", name: "Revuelto", fuelType: "hybrid_plugin", engineCc: 6498, batteryKwh: 3.8, powerKw: 735, weightKg: 1772, ncmCode: "87036000" },
  { id: "lambo-urus-se", brandId: "lamborghini", name: "Urus SE", fuelType: "hybrid_plugin", engineCc: 4000, batteryKwh: 25.7, powerKw: 588, weightKg: 2450, ncmCode: "87036000" },
  { id: "lambo-huracan", brandId: "lamborghini", name: "Huracán EVO", fuelType: "gasoline", engineCc: 5204, powerKw: 470, weightKg: 1422, ncmCode: "87032410" },
  { id: "lambo-urus", brandId: "lamborghini", name: "Urus", fuelType: "gasoline", engineCc: 3996, powerKw: 478, weightKg: 2200, ncmCode: "87032410" },
  
  // Maserati
  { id: "maserati-granturismo-folgore", brandId: "maserati", name: "GranTurismo Folgore", fuelType: "electric", batteryKwh: 92.5, powerKw: 560, weightKg: 2260, ncmCode: "87038000" },
  { id: "maserati-grecale-folgore", brandId: "maserati", name: "Grecale Folgore", fuelType: "electric", batteryKwh: 105, powerKw: 410, weightKg: 2220, ncmCode: "87038000" },
  { id: "maserati-mc20", brandId: "maserati", name: "MC20", fuelType: "gasoline", engineCc: 3000, powerKw: 463, weightKg: 1500, ncmCode: "87032290" },
  
  // Bentley
  { id: "bentley-continental-gt", brandId: "bentley", name: "Continental GT", fuelType: "gasoline", engineCc: 5950, powerKw: 485, weightKg: 2244, ncmCode: "87032410" },
  { id: "bentley-flying-spur", brandId: "bentley", name: "Flying Spur", fuelType: "hybrid_plugin", engineCc: 2995, batteryKwh: 18, powerKw: 410, weightKg: 2525, ncmCode: "87036000" },
  { id: "bentley-bentayga", brandId: "bentley", name: "Bentayga", fuelType: "gasoline", engineCc: 3996, powerKw: 404, weightKg: 2440, ncmCode: "87032410" },
  
  // Rolls-Royce
  { id: "rr-spectre", brandId: "rolls_royce", name: "Spectre", fuelType: "electric", batteryKwh: 102, powerKw: 430, weightKg: 2975, ncmCode: "87038000" },
  { id: "rr-phantom", brandId: "rolls_royce", name: "Phantom", fuelType: "gasoline", engineCc: 6749, powerKw: 420, weightKg: 2560, ncmCode: "87032410" },
  { id: "rr-cullinan", brandId: "rolls_royce", name: "Cullinan", fuelType: "gasoline", engineCc: 6749, powerKw: 420, weightKg: 2660, ncmCode: "87032410" },
  { id: "rr-ghost", brandId: "rolls_royce", name: "Ghost", fuelType: "gasoline", engineCc: 6749, powerKw: 420, weightKg: 2490, ncmCode: "87032410" },
  
  // McLaren
  { id: "mclaren-artura", brandId: "mclaren", name: "Artura", fuelType: "hybrid_plugin", engineCc: 2993, batteryKwh: 7.4, powerKw: 500, weightKg: 1498, ncmCode: "87036000" },
  { id: "mclaren-750s", brandId: "mclaren", name: "750S", fuelType: "gasoline", engineCc: 3994, powerKw: 552, weightKg: 1389, ncmCode: "87032410" },
  { id: "mclaren-720s", brandId: "mclaren", name: "720S", fuelType: "gasoline", engineCc: 3994, powerKw: 530, weightKg: 1283, ncmCode: "87032410" },
  
  // Aston Martin
  { id: "am-db12", brandId: "aston_martin", name: "DB12", fuelType: "gasoline", engineCc: 3982, powerKw: 500, weightKg: 1685, ncmCode: "87032410" },
  { id: "am-vantage", brandId: "aston_martin", name: "Vantage", fuelType: "gasoline", engineCc: 3982, powerKw: 503, weightKg: 1605, ncmCode: "87032410" },
  { id: "am-dbx707", brandId: "aston_martin", name: "DBX707", fuelType: "gasoline", engineCc: 3982, powerKw: 520, weightKg: 2245, ncmCode: "87032410" },
];

// NCM codes with 2026 tax rates - BASED ON SISCOMEX CLASSIF API
// Sources: SISCOMEX Classif (Res Camex 272/2021), GECEX 532/2023, 553/2024, TIPI, Lei 10.865/2004
// II Janeiro 2026: Elétricos 25%, Híbridos Plug-in 28%, Híbridos Convencionais 30%, Combustão 35%
// A partir de Julho 2026: Todos 35%
// PIS-Importação: 2.10% | COFINS-Importação: 9.65% (Veículos Cap. 87 - Lei 10.865/2004 Art. 8º §3º)
// IPI: Calculado conforme Decreto 12.549/2025 (NC 87-13) - valores base na tabela
export const ncmCodes: NcmCode[] = [
  // 8702 - Ônibus
  { code: "87021000", description: "Ônibus diesel para mais de 10 pessoas", iiRate: 35, ipiRate: 0, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.21.00 - Gasolina até 1000cc
  { code: "87032100", description: "Veículos gasolina até 1.000cc", iiRate: 35, ipiRate: 7, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.22.xx - Gasolina 1000cc a 1500cc
  { code: "87032210", description: "Veículos gasolina 1.000-1.500cc (até 6 pessoas)", iiRate: 35, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87032290", description: "Veículos gasolina 1.000-1.500cc (outros)", iiRate: 35, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.23.xx - Gasolina 1500cc a 3000cc
  { code: "87032310", description: "Veículos gasolina 1.500-3.000cc (até 6 pessoas)", iiRate: 35, ipiRate: 13, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87032390", description: "Veículos gasolina 1.500-3.000cc (outros)", iiRate: 35, ipiRate: 13, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.24.xx - Gasolina acima de 3000cc (veículos de luxo)
  { code: "87032410", description: "Veículos gasolina > 3.000cc (até 6 pessoas)", iiRate: 35, ipiRate: 25, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87032490", description: "Veículos gasolina > 3.000cc (outros)", iiRate: 35, ipiRate: 25, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.31.xx - Diesel até 1500cc
  { code: "87033110", description: "Veículos diesel até 1.500cc (até 6 pessoas)", iiRate: 35, ipiRate: 8, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87033190", description: "Veículos diesel até 1.500cc (outros)", iiRate: 35, ipiRate: 8, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.32.xx - Diesel 1500cc a 2500cc
  { code: "87033210", description: "Veículos diesel 1.500-2.500cc (até 6 pessoas)", iiRate: 35, ipiRate: 13, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87033290", description: "Veículos diesel 1.500-2.500cc (outros)", iiRate: 35, ipiRate: 13, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.33.xx - Diesel acima de 2500cc
  { code: "87033310", description: "Veículos diesel > 2.500cc (até 6 pessoas)", iiRate: 35, ipiRate: 25, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87033390", description: "Veículos diesel > 2.500cc (outros)", iiRate: 35, ipiRate: 25, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.40.00 - Híbridos convencionais gasolina (HEV/MHEV - não plug-in)
  { code: "87034000", description: "Híbrido convencional gasolina (HEV/MHEV)", iiRate: 30, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.50.00 - Híbridos convencionais diesel (não plug-in)
  { code: "87035000", description: "Híbrido convencional diesel", iiRate: 30, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.60.00 - Híbridos plug-in gasolina (PHEV)
  { code: "87036000", description: "Híbrido plug-in gasolina (PHEV)", iiRate: 28, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.70.00 - Híbridos plug-in diesel (PHEV)
  { code: "87037000", description: "Híbrido plug-in diesel (PHEV)", iiRate: 28, ipiRate: 11, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.80.00 - Veículos elétricos puros (BEV)
  { code: "87038000", description: "Veículo elétrico puro (BEV)", iiRate: 25, ipiRate: 0, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8703.90.00 - Outros veículos
  { code: "87039000", description: "Outros veículos", iiRate: 35, ipiRate: 7, pisRate: 2.1, cofinsRate: 9.65 },
  
  // 8704.xx - Caminhões
  { code: "87042110", description: "Caminhões diesel até 5 toneladas", iiRate: 35, ipiRate: 5, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87042290", description: "Caminhões diesel 5-20 toneladas", iiRate: 35, ipiRate: 5, pisRate: 2.1, cofinsRate: 9.65 },
  { code: "87042390", description: "Caminhões diesel > 20 toneladas", iiRate: 35, ipiRate: 5, pisRate: 2.1, cofinsRate: 9.65 },
];

// Helper functions for vehicle lookup
export function getVehicleModelsByBrand(brandId: string): VehicleModel[] {
  return vehicleModels.filter(m => m.brandId === brandId);
}

export function getVehicleNcm(modelId: string): NcmCode | undefined {
  const model = vehicleModels.find(m => m.id === modelId);
  if (!model) return undefined;
  return ncmCodes.find(n => n.code === model.ncmCode);
}

export function getFuelTypeLabel(fuelType: FuelType): string {
  const labels: Record<FuelType, string> = {
    electric: "Elétrico",
    hybrid_plugin: "Híbrido Plug-in",
    hybrid: "Híbrido",
    gasoline: "Gasolina",
    diesel: "Diesel",
  };
  return labels[fuelType];
}

// Static data - Origin locations
export const originLocations: Location[] = [
  // USA - Ports (Marítimo)
  { id: "us-mia-port", name: "Porto de Miami", code: "USMIA", country: "Estados Unidos", type: "port" },
  // Europe - Ports (Marítimo)
  { id: "eu-rtm-port", name: "Porto de Rotterdam", code: "NLRTM", country: "Europa", type: "port" },
  // USA - Airports (Aéreo)
  { id: "us-jfk-air", name: "Aeroporto JFK (Nova York)", code: "JFK", country: "Estados Unidos", type: "airport" },
  { id: "us-mia-air", name: "Aeroporto de Miami", code: "MIA", country: "Estados Unidos", type: "airport" },
];

// Static data - Brazilian destinations
export const destinationLocations: Location[] = [
  // Ports (Marítimo)
  { id: "br-ssz-port", name: "Porto de Santos", code: "BRSSZ", country: "Brasil", type: "port", state: "SP" },
  { id: "br-itj-port", name: "Porto de Itajaí", code: "BRITJ", country: "Brasil", type: "port", state: "SC" },
  // Airports (Aéreo)
  { id: "br-gru-air", name: "Aeroporto de Guarulhos", code: "GRU", country: "Brasil", type: "airport", state: "SP" },
  { id: "br-vcp-air", name: "Aeroporto de Viracopos", code: "VCP", country: "Brasil", type: "airport", state: "SP" },
];

// Brazilian states with ICMS rates
export const brazilianStates: BrazilianState[] = [
  { code: "SP", name: "São Paulo", icmsRate: 18 },
  { code: "RJ", name: "Rio de Janeiro", icmsRate: 20 },
  { code: "MG", name: "Minas Gerais", icmsRate: 18 },
  { code: "PR", name: "Paraná", icmsRate: 19.5 },
  { code: "SC", name: "Santa Catarina", icmsRate: 17 },
  { code: "RS", name: "Rio Grande do Sul", icmsRate: 17 },
  { code: "BA", name: "Bahia", icmsRate: 20.5 },
  { code: "PE", name: "Pernambuco", icmsRate: 20.5 },
  { code: "CE", name: "Ceará", icmsRate: 20 },
  { code: "ES", name: "Espírito Santo", icmsRate: 17 },
  { code: "AM", name: "Amazonas", icmsRate: 20 },
  { code: "DF", name: "Distrito Federal", icmsRate: 20 },
];

// Helper function to get ICMS rate by state
export function getIcmsRate(stateCode: string): number {
  const state = brazilianStates.find(s => s.code === stateCode);
  return state?.icmsRate ?? 18; // Default to 18%
}

// Freight cost estimates per kg (USD)
export const freightRates = {
  air: {
    china: 5.5,
    korea: 5.0,
    usa: 4.5,
  },
  maritime: {
    china: 0.35,
    korea: 0.30,
    usa: 0.25,
  },
};

// Siscomex fee
export const siscomexFees = {
  air: 92.0, // R$
  maritime: 185.0, // R$
};

// Insurance rate (% of CIF)
export const insuranceRate = 0.5; // 0.5%

// Operational expenses defaults (based on typical Brazilian import costs)
export const operationalDefaults = {
  // Maritime-specific
  maritime: {
    afrmmRate: 8, // 8% of maritime freight (AFRMM - Marinha Mercante)
    thc: 941, // R$ Terminal Handling Charge / Capatazias
    primaryStorageRate: 3, // % of CIF for first period
    removalFee: 4200, // R$ Remoção para Zona Secundária
    secondaryStorage: 2800, // R$ EADI first period
    cargoAgent: 0, // Included in THC for maritime
  },
  // Air-specific
  air: {
    afrmmRate: 0, // No AFRMM for air
    thc: 250, // R$ Capatazias aeroportuárias
    primaryStorageRate: 3, // % of CIF for first period
    removalFee: 1500, // R$ Remoção
    secondaryStorage: 0, // Usually not needed for air
    cargoAgent: 150, // R$ Agente de Carga
  },
  // Common fees
  common: {
    customsBrokerRate: 2.5, // % Despachante Aduaneiro (min 1.5% - max 3%)
    customsBrokerUnion: 2162, // R$ S.D.A - Sindicato Despachantes (fixed)
    domesticTransport: 750, // R$ Transporte Rodoviário / Entrega
    importLicense: 1412, // R$ Licença de Importação MDIC/IBAMA
    gruCat: 987.77, // R$ GRU/CAT
    denatran: 4000, // R$ DENATRAN (vehicles only)
  },
};
