# Design Guidelines: Import Cost Calculator

## Design Approach
**System-Based Approach** - Material Design 3
This utility-focused application prioritizes clarity, efficiency, and trustworthiness for complex financial calculations. Material Design provides the structure needed for data-heavy forms and calculations while maintaining visual professionalism.

## Core Design Principles
1. **Clarity First**: Every input, calculation, and result must be immediately understandable
2. **Professional Trust**: Clean, structured layouts that inspire confidence in financial calculations
3. **Guided Flow**: Clear visual hierarchy guiding users through the calculation process
4. **Data Transparency**: Tax breakdowns and cost components clearly visible

## Typography System
- **Primary Font**: Inter (Google Fonts) - excellent readability for forms and data
- **Headers**: Font weights 700 (main headings), 600 (section headers)
- **Body Text**: Font weight 400 for labels, 500 for emphasized values
- **Data/Numbers**: Font weight 600, tabular numbers for alignment
- **Sizes**: text-3xl/4xl (page titles), text-xl (section headers), text-base (labels), text-lg (input values)

## Layout System
**Spacing Primitives**: Tailwind units of 3, 4, 6, 8, 12
- Form sections: p-6, gap-4
- Card containers: p-8, mb-6
- Input fields: py-3, px-4
- Page margins: px-6 lg:px-12

**Grid Structure**:
- Main container: max-w-6xl mx-auto
- Two-column desktop layout: lg:grid-cols-2 for form inputs vs. live calculation preview
- Single column mobile: Everything stacks naturally

## Component Library

### Navigation
- Fixed top bar with logo, "Import Calculator" title, language toggle (PT/EN)
- Minimal, clean header - this is a tool, not marketing

### Calculator Form Card
- Large, prominent card (bg-white shadow-lg rounded-lg)
- Organized in logical sections with clear labels:
  1. Product Information (NCM search with autocomplete, product name)
  2. Financial Details (FOB value, quantity)
  3. Physical Specs (weight in kg)
  4. Logistics (origin/destination dropdowns with port/airport icons)
  5. Transport Mode (toggle buttons: Air/Maritime with icons)

### Input Components
- **Text Inputs**: Outlined style with floating labels, clear focus states
- **Dropdowns**: Custom select with search capability for locations/NCM codes
- **Number Inputs**: Currency formatting for FOB value, unit formatting for weight
- **Toggle**: Prominent Air/Maritime switch with icons (plane/ship)
- **Search NCM**: Autocomplete dropdown with NCM code + description

### Results Display
- **Live Calculation Panel**: Sticky sidebar (desktop) or section below form (mobile)
- **Tax Breakdown Card**: Each tax type displayed as row with label, percentage, calculated value
- **Total Cost Summary**: Prominent display with FOB + all taxes = final landed cost
- **Visual Breakdown**: Simple horizontal bar showing cost composition (product vs. taxes)

### Data Presentation
- Table format for tax breakdown with alternating row backgrounds
- Clear labeling: Tax type | Rate | Calculated Amount
- Currency formatting: R$ with proper thousand separators
- Highlight total in larger, bold text

### Call-to-Action
- Primary button: "Calculate Import Costs" (initially) / "Recalculate" (after first use)
- Secondary actions: "Export PDF", "Save Calculation", "Reset Form"
- Floating action button (mobile): Quick recalculate

## Page Structure
1. **Hero Section**: Compact (not full-screen) with value proposition
   - Heading: "Calculate Your Import Costs Instantly"
   - Subheading: "Air & Maritime Import Tax Calculator for Brazil"
   - Background: Subtle gradient or pattern suggesting logistics/shipping
   - Height: 30vh with centered content

2. **Calculator Section**: Main workspace
   - Split layout (desktop): Form left, live results right
   - Unified layout (mobile): Form → Results stacked

3. **Information Footer**: Brief explanation of taxes calculated, disclaimer, contact

## Icons
**Heroicons via CDN** for all interface icons:
- Calculator, plane, ship, search, location pin, document (export), refresh
- Tax-related icons for breakdown display

## Images
- **Hero Background**: Shipping containers or aerial view of port (subtle, overlaid)
- **No other images needed** - this is a functional tool

## Accessibility
- All form inputs with proper labels and aria-descriptions
- Clear focus indicators on all interactive elements
- Error states with color + icon + text (not color alone)
- Keyboard navigation through entire form
- Screen reader announcements for calculation results

## Unique Design Elements
- **NCM Search**: Smart autocomplete with highlighted matching text
- **Real-time Preview**: Calculations update as user types (with debounce)
- **Cost Visualization**: Simple progress bar showing tax burden percentage
- **Comparison Mode**: Toggle to compare air vs. maritime side-by-side

## Responsive Behavior
- Desktop: Two-column layout with sticky results panel
- Tablet: Stacked with results panel that scrolls with content
- Mobile: Full-stack layout, results collapse/expand below form

This design prioritizes efficiency and clarity for professional users making important financial decisions about imports.