# Import Cost Calculator

## Overview

A Brazilian import tax calculator web application that helps users estimate the total cost of importing products into Brazil. The application calculates various taxes (II, IPI, PIS, COFINS, ICMS) based on NCM codes, product specifications, origin/destination locations, and transport mode (air or maritime). Built as a full-stack TypeScript application with a React frontend and Express backend.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state
- **Forms**: React Hook Form with Zod validation
- **UI Components**: Shadcn/ui component library (New York style) built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **API Pattern**: RESTful endpoints under `/api/` prefix
- **Storage**: In-memory storage (MemStorage class) with interface designed for database migration
- **Shared Code**: Common schemas and calculator logic in `/shared` directory

### Data Flow
1. Client submits calculation inputs via form
2. Form data validated with Zod schemas (shared between client/server)
3. API processes request using calculator functions from shared module
4. Tax breakdown returned and displayed in real-time

### Key Design Patterns
- **Shared Schema Pattern**: Zod schemas in `/shared/schema.ts` used for both client validation and API contracts
- **Calculator as Pure Functions**: Tax calculation logic isolated in `/shared/calculator.ts` for testability
- **Component Composition**: Shadcn/ui primitives composed into domain-specific components
- **Path Aliases**: `@/` for client code, `@shared/` for shared modules

### Build System
- **Development**: Vite dev server with HMR, proxying API requests to Express
- **Production**: Vite builds static assets, esbuild bundles server code
- **Server Bundling**: Specific dependencies allowlisted for bundling to optimize cold start

## External Dependencies

### Database
- **ORM**: Drizzle ORM configured for PostgreSQL
- **Schema Location**: `/shared/schema.ts`
- **Migrations**: `/migrations` directory via `drizzle-kit push`
- **Note**: Currently using in-memory storage; database can be provisioned when needed

### UI Libraries
- **Radix UI**: Complete primitive set (dialog, popover, select, tabs, etc.)
- **Lucide Icons**: Icon library for UI elements
- **Embla Carousel**: Carousel functionality
- **CMDK**: Command palette component
- **Vaul**: Drawer component

### Form & Validation
- **React Hook Form**: Form state management
- **Zod**: Runtime type validation and schema definition
- **@hookform/resolvers**: Zod integration with React Hook Form

### Fonts
- Google Fonts: Inter (primary), DM Sans, Fira Code, Geist Mono

### Development Tools
- **Replit Plugins**: Error overlay, cartographer, dev banner
- **TypeScript**: Strict mode enabled with bundler module resolution